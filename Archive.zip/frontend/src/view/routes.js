import Permissions from 'security/permissions';
import { i18n } from 'i18n';
import React from 'react';
import HomeIcon from '@material-ui/icons/Home';
import PersonAddIcon from '@material-ui/icons/PersonAdd';
import HistoryIcon from '@material-ui/icons/History';
import SettingsIcon from '@material-ui/icons/Settings';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';

const permissions = Permissions.values;

const privateRoutes = [
  {
    path: '/',
    icon: <HomeIcon />,
    label: i18n('home.menu'),
    menu: {
      exact: true,
    },
    loader: () => import('view/home/HomePage'),
    permissionRequired: null,
    exact: true,
  },
  {
    path: '/profile',
    loader: () => import('view/auth/ProfileFormPage'),
    permissionRequired: null,
    exact: true,
    menu: false,
  },
  {
    path: '/iam',
    loader: () => import('view/iam/list/IamPage'),
    permissionRequired: permissions.iamRead,
    exact: true,
    icon: <PersonAddIcon />,
    label: i18n('iam.menu'),
    menu: true,
  },
  {
    path: '/iam/new',
    loader: () => import('view/iam/new/IamNewPage'),
    menu: false,
    permissionRequired: permissions.iamCreate,
    exact: true,
  },
  {
    path: '/iam/importer',
    loader: () =>
      import('view/iam/importer/IamImporterPage'),
    menu: false,
    permissionRequired: permissions.iamImport,
    exact: true,
  },
  {
    path: '/iam/:id/edit',
    loader: () => import('view/iam/edit/IamEditPage'),
    menu: false,
    permissionRequired: permissions.iamEdit,
    exact: true,
  },
  {
    path: '/iam/:id',
    loader: () => import('view/iam/view/IamViewPage'),
    menu: false,
    permissionRequired: permissions.iamRead,
    exact: true,
  },

  {
    path: '/audit-logs',
    icon: <HistoryIcon />,
    label: i18n('auditLog.menu'),
    loader: () => import('view/auditLog/AuditLogPage'),
    menu: true,
    permissionRequired: permissions.auditLogRead,
  },

  {
    path: '/settings',
    icon: <SettingsIcon />,
    label: i18n('settings.menu'),
    loader: () => import('view/settings/SettingsFormPage'),
    permissionRequired: permissions.settingsEdit,
    menu: true,
  },

  {
    path: '/persons',
    loader: () => import('view/persons/list/PersonsListPage'),
    permissionRequired: permissions.personsRead,
    exact: true,
    icon: <ChevronRightIcon />,
    label: i18n('entities.persons.menu'),
    menu: true,
  },
  {
    path: '/persons/new',
    loader: () => import('view/persons/form/PersonsFormPage'),
    menu: false,
    permissionRequired: permissions.personsCreate,
    exact: true,
  },
  {
    path: '/persons/importer',
    loader: () =>
      import('view/persons/importer/PersonsImporterPage'),
    menu: false,
    permissionRequired: permissions.personsImport,
    exact: true,
  },
  {
    path: '/persons/:id/edit',
    loader: () => import('view/persons/form/PersonsFormPage'),
    menu: false,
    permissionRequired: permissions.personsEdit,
    exact: true,
  },
  {
    path: '/persons/:id',
    loader: () => import('view/persons/view/PersonsViewPage'),
    menu: false,
    permissionRequired: permissions.personsRead,
    exact: true,
  },

  {
    path: '/stations',
    loader: () => import('view/stations/list/StationsListPage'),
    permissionRequired: permissions.stationsRead,
    exact: true,
    icon: <ChevronRightIcon />,
    label: i18n('entities.stations.menu'),
    menu: true,
  },
  {
    path: '/stations/new',
    loader: () => import('view/stations/form/StationsFormPage'),
    menu: false,
    permissionRequired: permissions.stationsCreate,
    exact: true,
  },
  {
    path: '/stations/importer',
    loader: () =>
      import('view/stations/importer/StationsImporterPage'),
    menu: false,
    permissionRequired: permissions.stationsImport,
    exact: true,
  },
  {
    path: '/stations/:id/edit',
    loader: () => import('view/stations/form/StationsFormPage'),
    menu: false,
    permissionRequired: permissions.stationsEdit,
    exact: true,
  },
  {
    path: '/stations/:id',
    loader: () => import('view/stations/view/StationsViewPage'),
    menu: false,
    permissionRequired: permissions.stationsRead,
    exact: true,
  },

  {
    path: '/addresses',
    loader: () => import('view/addresses/list/AddressesListPage'),
    permissionRequired: permissions.addressesRead,
    exact: true,
    icon: <ChevronRightIcon />,
    label: i18n('entities.addresses.menu'),
    menu: true,
  },
  {
    path: '/addresses/new',
    loader: () => import('view/addresses/form/AddressesFormPage'),
    menu: false,
    permissionRequired: permissions.addressesCreate,
    exact: true,
  },
  {
    path: '/addresses/importer',
    loader: () =>
      import('view/addresses/importer/AddressesImporterPage'),
    menu: false,
    permissionRequired: permissions.addressesImport,
    exact: true,
  },
  {
    path: '/addresses/:id/edit',
    loader: () => import('view/addresses/form/AddressesFormPage'),
    menu: false,
    permissionRequired: permissions.addressesEdit,
    exact: true,
  },
  {
    path: '/addresses/:id',
    loader: () => import('view/addresses/view/AddressesViewPage'),
    menu: false,
    permissionRequired: permissions.addressesRead,
    exact: true,
  },

  {
    path: '/maintenance-templates',
    loader: () => import('view/maintenanceTemplates/list/MaintenanceTemplatesListPage'),
    permissionRequired: permissions.maintenanceTemplatesRead,
    exact: true,
    icon: <ChevronRightIcon />,
    label: i18n('entities.maintenanceTemplates.menu'),
    menu: true,
  },
  {
    path: '/maintenance-templates/new',
    loader: () => import('view/maintenanceTemplates/form/MaintenanceTemplatesFormPage'),
    menu: false,
    permissionRequired: permissions.maintenanceTemplatesCreate,
    exact: true,
  },
  {
    path: '/maintenance-templates/importer',
    loader: () =>
      import('view/maintenanceTemplates/importer/MaintenanceTemplatesImporterPage'),
    menu: false,
    permissionRequired: permissions.maintenanceTemplatesImport,
    exact: true,
  },
  {
    path: '/maintenance-templates/:id/edit',
    loader: () => import('view/maintenanceTemplates/form/MaintenanceTemplatesFormPage'),
    menu: false,
    permissionRequired: permissions.maintenanceTemplatesEdit,
    exact: true,
  },
  {
    path: '/maintenance-templates/:id',
    loader: () => import('view/maintenanceTemplates/view/MaintenanceTemplatesViewPage'),
    menu: false,
    permissionRequired: permissions.maintenanceTemplatesRead,
    exact: true,
  },

  {
    path: '/category-types',
    loader: () => import('view/categoryTypes/list/CategoryTypesListPage'),
    permissionRequired: permissions.categoryTypesRead,
    exact: true,
    icon: <ChevronRightIcon />,
    label: i18n('entities.categoryTypes.menu'),
    menu: true,
  },
  {
    path: '/category-types/new',
    loader: () => import('view/categoryTypes/form/CategoryTypesFormPage'),
    menu: false,
    permissionRequired: permissions.categoryTypesCreate,
    exact: true,
  },
  {
    path: '/category-types/importer',
    loader: () =>
      import('view/categoryTypes/importer/CategoryTypesImporterPage'),
    menu: false,
    permissionRequired: permissions.categoryTypesImport,
    exact: true,
  },
  {
    path: '/category-types/:id/edit',
    loader: () => import('view/categoryTypes/form/CategoryTypesFormPage'),
    menu: false,
    permissionRequired: permissions.categoryTypesEdit,
    exact: true,
  },
  {
    path: '/category-types/:id',
    loader: () => import('view/categoryTypes/view/CategoryTypesViewPage'),
    menu: false,
    permissionRequired: permissions.categoryTypesRead,
    exact: true,
  },

  {
    path: '/task-templates',
    loader: () => import('view/taskTemplates/list/TaskTemplatesListPage'),
    permissionRequired: permissions.taskTemplatesRead,
    exact: true,
    icon: <ChevronRightIcon />,
    label: i18n('entities.taskTemplates.menu'),
    menu: true,
  },
  {
    path: '/task-templates/new',
    loader: () => import('view/taskTemplates/form/TaskTemplatesFormPage'),
    menu: false,
    permissionRequired: permissions.taskTemplatesCreate,
    exact: true,
  },
  {
    path: '/task-templates/importer',
    loader: () =>
      import('view/taskTemplates/importer/TaskTemplatesImporterPage'),
    menu: false,
    permissionRequired: permissions.taskTemplatesImport,
    exact: true,
  },
  {
    path: '/task-templates/:id/edit',
    loader: () => import('view/taskTemplates/form/TaskTemplatesFormPage'),
    menu: false,
    permissionRequired: permissions.taskTemplatesEdit,
    exact: true,
  },
  {
    path: '/task-templates/:id',
    loader: () => import('view/taskTemplates/view/TaskTemplatesViewPage'),
    menu: false,
    permissionRequired: permissions.taskTemplatesRead,
    exact: true,
  },

  {
    path: '/work-orders',
    loader: () => import('view/workOrders/list/WorkOrdersListPage'),
    permissionRequired: permissions.workOrdersRead,
    exact: true,
    icon: <ChevronRightIcon />,
    label: i18n('entities.workOrders.menu'),
    menu: true,
  },
  {
    path: '/work-orders/new',
    loader: () => import('view/workOrders/form/WorkOrdersFormPage'),
    menu: false,
    permissionRequired: permissions.workOrdersCreate,
    exact: true,
  },
  {
    path: '/work-orders/importer',
    loader: () =>
      import('view/workOrders/importer/WorkOrdersImporterPage'),
    menu: false,
    permissionRequired: permissions.workOrdersImport,
    exact: true,
  },
  {
    path: '/work-orders/:id/edit',
    loader: () => import('view/workOrders/form/WorkOrdersFormPage'),
    menu: false,
    permissionRequired: permissions.workOrdersEdit,
    exact: true,
  },
  {
    path: '/work-orders/:id',
    loader: () => import('view/workOrders/view/WorkOrdersViewPage'),
    menu: false,
    permissionRequired: permissions.workOrdersRead,
    exact: true,
  },

  {
    path: '/tasks',
    loader: () => import('view/tasks/list/TasksListPage'),
    permissionRequired: permissions.tasksRead,
    exact: true,
    icon: <ChevronRightIcon />,
    label: i18n('entities.tasks.menu'),
    menu: true,
  },
  {
    path: '/tasks/new',
    loader: () => import('view/tasks/form/TasksFormPage'),
    menu: false,
    permissionRequired: permissions.tasksCreate,
    exact: true,
  },
  {
    path: '/tasks/importer',
    loader: () =>
      import('view/tasks/importer/TasksImporterPage'),
    menu: false,
    permissionRequired: permissions.tasksImport,
    exact: true,
  },
  {
    path: '/tasks/:id/edit',
    loader: () => import('view/tasks/form/TasksFormPage'),
    menu: false,
    permissionRequired: permissions.tasksEdit,
    exact: true,
  },
  {
    path: '/tasks/:id',
    loader: () => import('view/tasks/view/TasksViewPage'),
    menu: false,
    permissionRequired: permissions.tasksRead,
    exact: true,
  },

  {
    path: '/maintenance-types',
    loader: () => import('view/maintenanceTypes/list/MaintenanceTypesListPage'),
    permissionRequired: permissions.maintenanceTypesRead,
    exact: true,
    icon: <ChevronRightIcon />,
    label: i18n('entities.maintenanceTypes.menu'),
    menu: true,
  },
  {
    path: '/maintenance-types/new',
    loader: () => import('view/maintenanceTypes/form/MaintenanceTypesFormPage'),
    menu: false,
    permissionRequired: permissions.maintenanceTypesCreate,
    exact: true,
  },
  {
    path: '/maintenance-types/importer',
    loader: () =>
      import('view/maintenanceTypes/importer/MaintenanceTypesImporterPage'),
    menu: false,
    permissionRequired: permissions.maintenanceTypesImport,
    exact: true,
  },
  {
    path: '/maintenance-types/:id/edit',
    loader: () => import('view/maintenanceTypes/form/MaintenanceTypesFormPage'),
    menu: false,
    permissionRequired: permissions.maintenanceTypesEdit,
    exact: true,
  },
  {
    path: '/maintenance-types/:id',
    loader: () => import('view/maintenanceTypes/view/MaintenanceTypesViewPage'),
    menu: false,
    permissionRequired: permissions.maintenanceTypesRead,
    exact: true,
  },

  {
    path: '/periodicity-types',
    loader: () => import('view/periodicityTypes/list/PeriodicityTypesListPage'),
    permissionRequired: permissions.periodicityTypesRead,
    exact: true,
    icon: <ChevronRightIcon />,
    label: i18n('entities.periodicityTypes.menu'),
    menu: true,
  },
  {
    path: '/periodicity-types/new',
    loader: () => import('view/periodicityTypes/form/PeriodicityTypesFormPage'),
    menu: false,
    permissionRequired: permissions.periodicityTypesCreate,
    exact: true,
  },
  {
    path: '/periodicity-types/importer',
    loader: () =>
      import('view/periodicityTypes/importer/PeriodicityTypesImporterPage'),
    menu: false,
    permissionRequired: permissions.periodicityTypesImport,
    exact: true,
  },
  {
    path: '/periodicity-types/:id/edit',
    loader: () => import('view/periodicityTypes/form/PeriodicityTypesFormPage'),
    menu: false,
    permissionRequired: permissions.periodicityTypesEdit,
    exact: true,
  },
  {
    path: '/periodicity-types/:id',
    loader: () => import('view/periodicityTypes/view/PeriodicityTypesViewPage'),
    menu: false,
    permissionRequired: permissions.periodicityTypesRead,
    exact: true,
  },

  {
    path: '/fuel-types',
    loader: () => import('view/fuelTypes/list/FuelTypesListPage'),
    permissionRequired: permissions.fuelTypesRead,
    exact: true,
    icon: <ChevronRightIcon />,
    label: i18n('entities.fuelTypes.menu'),
    menu: true,
  },
  {
    path: '/fuel-types/new',
    loader: () => import('view/fuelTypes/form/FuelTypesFormPage'),
    menu: false,
    permissionRequired: permissions.fuelTypesCreate,
    exact: true,
  },
  {
    path: '/fuel-types/importer',
    loader: () =>
      import('view/fuelTypes/importer/FuelTypesImporterPage'),
    menu: false,
    permissionRequired: permissions.fuelTypesImport,
    exact: true,
  },
  {
    path: '/fuel-types/:id/edit',
    loader: () => import('view/fuelTypes/form/FuelTypesFormPage'),
    menu: false,
    permissionRequired: permissions.fuelTypesEdit,
    exact: true,
  },
  {
    path: '/fuel-types/:id',
    loader: () => import('view/fuelTypes/view/FuelTypesViewPage'),
    menu: false,
    permissionRequired: permissions.fuelTypesRead,
    exact: true,
  },

  {
    path: '/tanks',
    loader: () => import('view/tanks/list/TanksListPage'),
    permissionRequired: permissions.tanksRead,
    exact: true,
    icon: <ChevronRightIcon />,
    label: i18n('entities.tanks.menu'),
    menu: true,
  },
  {
    path: '/tanks/new',
    loader: () => import('view/tanks/form/TanksFormPage'),
    menu: false,
    permissionRequired: permissions.tanksCreate,
    exact: true,
  },
  {
    path: '/tanks/importer',
    loader: () =>
      import('view/tanks/importer/TanksImporterPage'),
    menu: false,
    permissionRequired: permissions.tanksImport,
    exact: true,
  },
  {
    path: '/tanks/:id/edit',
    loader: () => import('view/tanks/form/TanksFormPage'),
    menu: false,
    permissionRequired: permissions.tanksEdit,
    exact: true,
  },
  {
    path: '/tanks/:id',
    loader: () => import('view/tanks/view/TanksViewPage'),
    menu: false,
    permissionRequired: permissions.tanksRead,
    exact: true,
  },

  {
    path: '/product-reception',
    loader: () => import('view/productReception/list/ProductReceptionListPage'),
    permissionRequired: permissions.productReceptionRead,
    exact: true,
    icon: <ChevronRightIcon />,
    label: i18n('entities.productReception.menu'),
    menu: true,
  },
  {
    path: '/product-reception/new',
    loader: () => import('view/productReception/form/ProductReceptionFormPage'),
    menu: false,
    permissionRequired: permissions.productReceptionCreate,
    exact: true,
  },
  {
    path: '/product-reception/importer',
    loader: () =>
      import('view/productReception/importer/ProductReceptionImporterPage'),
    menu: false,
    permissionRequired: permissions.productReceptionImport,
    exact: true,
  },
  {
    path: '/product-reception/:id/edit',
    loader: () => import('view/productReception/form/ProductReceptionFormPage'),
    menu: false,
    permissionRequired: permissions.productReceptionEdit,
    exact: true,
  },
  {
    path: '/product-reception/:id',
    loader: () => import('view/productReception/view/ProductReceptionViewPage'),
    menu: false,
    permissionRequired: permissions.productReceptionRead,
    exact: true,
  },

  {
    path: '/product-deviation',
    loader: () => import('view/productDeviation/list/ProductDeviationListPage'),
    permissionRequired: permissions.productDeviationRead,
    exact: true,
    icon: <ChevronRightIcon />,
    label: i18n('entities.productDeviation.menu'),
    menu: true,
  },
  {
    path: '/product-deviation/new',
    loader: () => import('view/productDeviation/form/ProductDeviationFormPage'),
    menu: false,
    permissionRequired: permissions.productDeviationCreate,
    exact: true,
  },
  {
    path: '/product-deviation/importer',
    loader: () =>
      import('view/productDeviation/importer/ProductDeviationImporterPage'),
    menu: false,
    permissionRequired: permissions.productDeviationImport,
    exact: true,
  },
  {
    path: '/product-deviation/:id/edit',
    loader: () => import('view/productDeviation/form/ProductDeviationFormPage'),
    menu: false,
    permissionRequired: permissions.productDeviationEdit,
    exact: true,
  },
  {
    path: '/product-deviation/:id',
    loader: () => import('view/productDeviation/view/ProductDeviationViewPage'),
    menu: false,
    permissionRequired: permissions.productDeviationRead,
    exact: true,
  },
];

const publicRoutes = [
  {
    path: '/auth/signin',
    loader: () => import('view/auth/SigninPage'),
  },
  {
    path: '/auth/signup',
    loader: () => import('view/auth/SignupPage'),
  },
  {
    path: '/auth/forgot-password',
    loader: () => import('view/auth/ForgotPasswordPage'),
  },
];

const emptyPermissionsRoutes = [
  {
    path: '/auth/empty-permissions',
    loader: () => import('view/auth/EmptyPermissionsPage'),
  },
];

const emailUnverifiedRoutes = [
  {
    path: '/auth/email-unverified',
    loader: () => import('view/auth/EmailUnverifiedPage'),
  },
];

const simpleRoutes = [
  {
    path: '/403',
    loader: () => import('view/shared/errors/Error403Page'),
  },
  {
    path: '/500',
    loader: () => import('view/shared/errors/Error500Page'),
  },
  {
    path: '**',
    loader: () => import('view/shared/errors/Error404Page'),
  },
];

export default {
  privateRoutes,
  publicRoutes,
  emptyPermissionsRoutes,
  emailUnverifiedRoutes,
  simpleRoutes,
};
