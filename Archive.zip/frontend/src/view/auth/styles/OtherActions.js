import { styled } from '@material-ui/core/styles';

const OtherActions = styled('div')({
  marginTop: '24px',
  textAlign: 'center',
});

export default OtherActions;
