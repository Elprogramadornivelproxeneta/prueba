import React, { Component } from 'react';
import StationsListFilter from 'view/stations/list/StationsListFilter';
import StationsListTable from 'view/stations/list/StationsListTable';
import StationsListToolbar from 'view/stations/list/StationsListToolbar';
import ContentWrapper from 'view/layout/styles/ContentWrapper';
import PageTitle from 'view/shared/styles/PageTitle';
import Breadcrumb from 'view/shared/Breadcrumb';
import { i18n } from 'i18n';

class StationsListPage extends Component {
  render() {
    return (
      <React.Fragment>
        <Breadcrumb
          items={[
            [i18n('home.menu'), '/'],
            [i18n('entities.stations.menu')],
          ]}
        />

        <ContentWrapper>
          <PageTitle>
            {i18n('entities.stations.list.title')}
          </PageTitle>

          <StationsListToolbar />
          <StationsListFilter />
          <StationsListTable />
        </ContentWrapper>
      </React.Fragment>
    );
  }
}

export default StationsListPage;
