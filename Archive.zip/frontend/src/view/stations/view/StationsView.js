import model from 'modules/stations/stationsModel';
import React, { Component } from 'react';
import Spinner from 'view/shared/Spinner';
import TextViewItem from 'view/shared/view/TextViewItem';
import AddressesViewItem from 'view/addresses/view/AddressesViewItem';
import PersonsViewItem from 'view/persons/view/PersonsViewItem';
import MaintenanceTemplatesViewItem from 'view/maintenanceTemplates/view/MaintenanceTemplatesViewItem';
import TanksViewItem from 'view/tanks/view/TanksViewItem';

const { fields } = model;

class StationsView extends Component {
  renderView() {
    const { record } = this.props;

    return (
      <div>
        <TextViewItem
          label={fields.id.label}
          value={fields.id.forView(record.id)}
        />

        <TextViewItem
          label={fields.identifier.label}
          value={fields.identifier.forView(record.identifier)}
        />

        <TextViewItem
          label={fields.name.label}
          value={fields.name.forView(record.name)}
        />

        <AddressesViewItem
          label={fields.address.label}
          value={fields.address.forView(record.address)}
        />

        <PersonsViewItem
          label={fields.legalRepresentative.label}
          value={fields.legalRepresentative.forView(record.legalRepresentative)}
        />

        <PersonsViewItem
          label={fields.users.label}
          value={fields.users.forView(record.users)}
        />

        <MaintenanceTemplatesViewItem
          label={fields.maintenanceTemplates.label}
          value={fields.maintenanceTemplates.forView(record.maintenanceTemplates)}
        />

        <TanksViewItem
          label={fields.tanks.label}
          value={fields.tanks.forView(record.tanks)}
        />

        <TextViewItem
          label={fields.createdAt.label}
          value={fields.createdAt.forView(record.createdAt)}
        />

        <TextViewItem
          label={fields.updatedAt.label}
          value={fields.updatedAt.forView(record.updatedAt)}
        />
      </div>
    );
  }

  render() {
    const { record, loading } = this.props;

    if (loading || !record) {
      return <Spinner />;
    }

    return this.renderView();
  }
}

export default StationsView;
