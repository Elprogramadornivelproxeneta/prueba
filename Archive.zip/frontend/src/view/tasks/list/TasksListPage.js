import React, { Component } from 'react';
import TasksListFilter from 'view/tasks/list/TasksListFilter';
import TasksListTable from 'view/tasks/list/TasksListTable';
import TasksListToolbar from 'view/tasks/list/TasksListToolbar';
import ContentWrapper from 'view/layout/styles/ContentWrapper';
import PageTitle from 'view/shared/styles/PageTitle';
import Breadcrumb from 'view/shared/Breadcrumb';
import { i18n } from 'i18n';

class TasksListPage extends Component {
  render() {
    return (
      <React.Fragment>
        <Breadcrumb
          items={[
            [i18n('home.menu'), '/'],
            [i18n('entities.tasks.menu')],
          ]}
        />

        <ContentWrapper>
          <PageTitle>
            {i18n('entities.tasks.list.title')}
          </PageTitle>

          <TasksListToolbar />
          <TasksListFilter />
          <TasksListTable />
        </ContentWrapper>
      </React.Fragment>
    );
  }
}

export default TasksListPage;
