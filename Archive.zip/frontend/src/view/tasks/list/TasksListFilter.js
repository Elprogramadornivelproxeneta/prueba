import { Formik } from 'formik';
import { i18n } from 'i18n';
import actions from 'modules/tasks/list/tasksListActions';
import selectors from 'modules/tasks/list/tasksListSelectors';
import model from 'modules/tasks/tasksModel';
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import FormFilterSchema from 'view/shared/form/formFilterSchema';
import InputFormItem from 'view/shared/form/items/InputFormItem';
// eslint-disable-next-line
import DatePickerRangeFormItem from 'view/shared/form/items/DatePickerRangeFormItem';
import FilterWrapper, {
  FilterButtons,
} from 'view/shared/styles/FilterWrapper';
import SearchIcon from '@material-ui/icons/Search';
import UndoIcon from '@material-ui/icons/Undo';
import { Button, Grid } from '@material-ui/core';
import SelectFormItem from 'view/shared/form/items/SelectFormItem';
import WorkOrdersAutocompleteFormItem from 'view/workOrders/autocomplete/WorkOrdersAutocompleteFormItem';
import TaskTemplatesAutocompleteFormItem from 'view/taskTemplates/autocomplete/TaskTemplatesAutocompleteFormItem';

const { fields } = model;

const schema = new FormFilterSchema([
  fields.result,
  fields.workOrderId,
  fields.taskTemplateId,
  fields.name,
]);

class TasksListFilter extends Component {
  componentDidMount() {
    const { dispatch } = this.props;
    dispatch(actions.doFetch(this.initialFilter()));
  }

  initialFilter = () => {
    return schema.initialValues(
      this.props.filter,
      this.props.location,
    );
  };

  handleSubmit = (values) => {
    const valuesToSubmit = schema.cast(values);
    const { dispatch } = this.props;
    dispatch(actions.doFetch(valuesToSubmit));
  };

  handleReset = (form) => {
    form.setValues({});
    const { dispatch } = this.props;
    dispatch(actions.doReset());
  };

  render() {
    const { loading } = this.props;

    return (
      <FilterWrapper>
        <Formik
          initialValues={this.initialFilter()}
          validationSchema={schema.schema}
          onSubmit={this.handleSubmit}
          render={(form) => {
            return (
              <form onSubmit={form.handleSubmit}>
                <Grid container spacing={2}>
                  <Grid item lg={6} xs={12}>
                    <SelectFormItem
                      name={fields.result.name}
                      label={fields.result.label}
                      options={fields.result.options.map(
                        (item) => ({
                          value: item.id,
                          label: item.label,
                        }),
                      )}
                    />
                  </Grid>
                  <Grid item lg={6} xs={12}>
                    <WorkOrdersAutocompleteFormItem
                      name={fields.workOrderId.name}
                      label={fields.workOrderId.label}
                    />
                  </Grid>
                  <Grid item lg={6} xs={12}>
                    <TaskTemplatesAutocompleteFormItem
                      name={fields.taskTemplateId.name}
                      label={fields.taskTemplateId.label}
                    />
                  </Grid>
                  <Grid item lg={6} xs={12}>
                    <InputFormItem
                      name={fields.name.name}
                      label={fields.name.label}
                    />
                  </Grid>
                </Grid>

                <FilterButtons>
                  <Button
                    variant="contained"
                    color="primary"
                    type="submit"
                    disabled={loading}
                    startIcon={<SearchIcon />}
                  >
                    {i18n('common.search')}
                  </Button>

                  <Button
                    type="button"
                    onClick={() => this.handleReset(form)}
                    disabled={loading}
                    startIcon={<UndoIcon />}
                  >
                    {i18n('common.reset')}
                  </Button>
                </FilterButtons>
              </form>
            );
          }}
        />
      </FilterWrapper>
    );
  }
}

function select(state) {
  return {
    filter: selectors.selectFilter(state),
  };
}

export default withRouter(connect(select)(TasksListFilter));
