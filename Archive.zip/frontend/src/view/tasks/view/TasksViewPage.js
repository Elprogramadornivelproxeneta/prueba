import React, { Component } from 'react';
import ContentWrapper from 'view/layout/styles/ContentWrapper';
import PageTitle from 'view/shared/styles/PageTitle';
import Breadcrumb from 'view/shared/Breadcrumb';
import TasksView from 'view/tasks/view/TasksView';
import { i18n } from 'i18n';
import actions from 'modules/tasks/view/tasksViewActions';
import { connect } from 'react-redux';
import selectors from 'modules/tasks/view/tasksViewSelectors';
import TasksViewToolbar from 'view/tasks/view/TasksViewToolbar';

class TasksPage extends Component {
  componentDidMount() {
    const { dispatch, match } = this.props;
    dispatch(actions.doFind(match.params.id));
  }

  render() {
    return (
      <React.Fragment>
        <Breadcrumb
          items={[
            [i18n('home.menu'), '/'],
            [i18n('entities.tasks.menu'), '/tasks'],
            [i18n('entities.tasks.view.title')],
          ]}
        />

        <ContentWrapper>
          <PageTitle>
            {i18n('entities.tasks.view.title')}
          </PageTitle>

          <TasksViewToolbar match={this.props.match} />

          <TasksView
            loading={this.props.loading}
            record={this.props.record}
          />
        </ContentWrapper>
      </React.Fragment>
    );
  }
}

function select(state) {
  return {
    loading: selectors.selectLoading(state),
    record: selectors.selectRecord(state),
  };
}

export default connect(select)(TasksPage);
