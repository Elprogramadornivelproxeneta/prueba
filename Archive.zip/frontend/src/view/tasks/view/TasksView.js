import model from 'modules/tasks/tasksModel';
import React, { Component } from 'react';
import Spinner from 'view/shared/Spinner';
import TextViewItem from 'view/shared/view/TextViewItem';
import ImagesViewItem from 'view/shared/view/ImagesViewItem';
import WorkOrdersViewItem from 'view/workOrders/view/WorkOrdersViewItem';
import TaskTemplatesViewItem from 'view/taskTemplates/view/TaskTemplatesViewItem';

const { fields } = model;

class TasksView extends Component {
  renderView() {
    const { record } = this.props;

    return (
      <div>
        <TextViewItem
          label={fields.id.label}
          value={fields.id.forView(record.id)}
        />

        <TextViewItem
          label={fields.result.label}
          value={fields.result.forView(record.result)}
        />

        <ImagesViewItem
          label={fields.evidences.label}
          value={fields.evidences.forView(record.evidences)}
        />

        <WorkOrdersViewItem
          label={fields.workOrderId.label}
          value={fields.workOrderId.forView(record.workOrderId)}
        />

        <TaskTemplatesViewItem
          label={fields.taskTemplateId.label}
          value={fields.taskTemplateId.forView(record.taskTemplateId)}
        />

        <TextViewItem
          label={fields.name.label}
          value={fields.name.forView(record.name)}
        />

        <TextViewItem
          label={fields.createdAt.label}
          value={fields.createdAt.forView(record.createdAt)}
        />

        <TextViewItem
          label={fields.updatedAt.label}
          value={fields.updatedAt.forView(record.updatedAt)}
        />
      </div>
    );
  }

  render() {
    const { record, loading } = this.props;

    if (loading || !record) {
      return <Spinner />;
    }

    return this.renderView();
  }
}

export default TasksView;
