import { styled } from '@material-ui/core/styles';

const PageTitle = styled('h1')({
  marginBottom: '36px',
});

export default PageTitle;
