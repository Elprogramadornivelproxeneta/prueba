export default class {
  static error(message) {}
  static success(message) {}
}
