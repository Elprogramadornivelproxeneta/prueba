import React, { Component } from 'react';
import ProductDeviationListFilter from 'view/productDeviation/list/ProductDeviationListFilter';
import ProductDeviationListTable from 'view/productDeviation/list/ProductDeviationListTable';
import ProductDeviationListToolbar from 'view/productDeviation/list/ProductDeviationListToolbar';
import ContentWrapper from 'view/layout/styles/ContentWrapper';
import PageTitle from 'view/shared/styles/PageTitle';
import Breadcrumb from 'view/shared/Breadcrumb';
import { i18n } from 'i18n';

class ProductDeviationListPage extends Component {
  render() {
    return (
      <React.Fragment>
        <Breadcrumb
          items={[
            [i18n('home.menu'), '/'],
            [i18n('entities.productDeviation.menu')],
          ]}
        />

        <ContentWrapper>
          <PageTitle>
            {i18n('entities.productDeviation.list.title')}
          </PageTitle>

          <ProductDeviationListToolbar />
          <ProductDeviationListFilter />
          <ProductDeviationListTable />
        </ContentWrapper>
      </React.Fragment>
    );
  }
}

export default ProductDeviationListPage;
