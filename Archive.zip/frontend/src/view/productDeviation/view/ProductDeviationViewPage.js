import React, { Component } from 'react';
import ContentWrapper from 'view/layout/styles/ContentWrapper';
import PageTitle from 'view/shared/styles/PageTitle';
import Breadcrumb from 'view/shared/Breadcrumb';
import ProductDeviationView from 'view/productDeviation/view/ProductDeviationView';
import { i18n } from 'i18n';
import actions from 'modules/productDeviation/view/productDeviationViewActions';
import { connect } from 'react-redux';
import selectors from 'modules/productDeviation/view/productDeviationViewSelectors';
import ProductDeviationViewToolbar from 'view/productDeviation/view/ProductDeviationViewToolbar';

class ProductDeviationPage extends Component {
  componentDidMount() {
    const { dispatch, match } = this.props;
    dispatch(actions.doFind(match.params.id));
  }

  render() {
    return (
      <React.Fragment>
        <Breadcrumb
          items={[
            [i18n('home.menu'), '/'],
            [i18n('entities.productDeviation.menu'), '/product-deviation'],
            [i18n('entities.productDeviation.view.title')],
          ]}
        />

        <ContentWrapper>
          <PageTitle>
            {i18n('entities.productDeviation.view.title')}
          </PageTitle>

          <ProductDeviationViewToolbar match={this.props.match} />

          <ProductDeviationView
            loading={this.props.loading}
            record={this.props.record}
          />
        </ContentWrapper>
      </React.Fragment>
    );
  }
}

function select(state) {
  return {
    loading: selectors.selectLoading(state),
    record: selectors.selectRecord(state),
  };
}

export default connect(select)(ProductDeviationPage);
