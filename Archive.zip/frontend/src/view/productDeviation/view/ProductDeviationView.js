import model from 'modules/productDeviation/productDeviationModel';
import React, { Component } from 'react';
import Spinner from 'view/shared/Spinner';
import TextViewItem from 'view/shared/view/TextViewItem';
import TanksViewItem from 'view/tanks/view/TanksViewItem';

const { fields } = model;

class ProductDeviationView extends Component {
  renderView() {
    const { record } = this.props;

    return (
      <div>
        <TextViewItem
          label={fields.id.label}
          value={fields.id.forView(record.id)}
        />

        <TanksViewItem
          label={fields.tank.label}
          value={fields.tank.forView(record.tank)}
        />

        <TextViewItem
          label={fields.initialInventoryVedeer.label}
          value={fields.initialInventoryVedeer.forView(record.initialInventoryVedeer)}
        />

        <TextViewItem
          label={fields.finalInventoryVedeer.label}
          value={fields.finalInventoryVedeer.forView(record.finalInventoryVedeer)}
        />

        <TextViewItem
          label={fields.volumePurchased.label}
          value={fields.volumePurchased.forView(record.volumePurchased)}
        />

        <TextViewItem
          label={fields.volumeSold.label}
          value={fields.volumeSold.forView(record.volumeSold)}
        />

        <TextViewItem
          label={fields.finalPhysicalInventory.label}
          value={fields.finalPhysicalInventory.forView(record.finalPhysicalInventory)}
        />

        <TextViewItem
          label={fields.difference.label}
          value={fields.difference.forView(record.difference)}
        />

        <TextViewItem
          label={fields.createdAt.label}
          value={fields.createdAt.forView(record.createdAt)}
        />

        <TextViewItem
          label={fields.updatedAt.label}
          value={fields.updatedAt.forView(record.updatedAt)}
        />
      </div>
    );
  }

  render() {
    const { record, loading } = this.props;

    if (loading || !record) {
      return <Spinner />;
    }

    return this.renderView();
  }
}

export default ProductDeviationView;
