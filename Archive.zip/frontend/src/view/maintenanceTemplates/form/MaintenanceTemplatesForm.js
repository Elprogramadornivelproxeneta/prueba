import { Button } from '@material-ui/core';
import CloseIcon from '@material-ui/icons/Close';
import SaveIcon from '@material-ui/icons/Save';
import UndoIcon from '@material-ui/icons/Undo';
import { Formik } from 'formik';
import { i18n } from 'i18n';
import model from 'modules/maintenanceTemplates/maintenanceTemplatesModel';
import React, { Component } from 'react';
import FormSchema from 'view/shared/form/formSchema';
import Spinner from 'view/shared/Spinner';
import FormWrapper, {
  FormButtons,
} from 'view/shared/styles/FormWrapper';
import ViewFormItem from 'view/shared/form/items/ViewFormItem';
import InputFormItem from 'view/shared/form/items/InputFormItem';
import TextAreaFormItem from 'view/shared/form/items/TextAreaFormItem';
import InputNumberFormItem from 'view/shared/form/items/InputNumberFormItem';
import SwitchFormItem from 'view/shared/form/items/SwitchFormItem';
import SelectFormItem from 'view/shared/form/items/SelectFormItem';
import MaintenanceTypesAutocompleteFormItem from 'view/maintenanceTypes/autocomplete/MaintenanceTypesAutocompleteFormItem';
import CategoryTypesAutocompleteFormItem from 'view/categoryTypes/autocomplete/CategoryTypesAutocompleteFormItem';
import PeriodicityTypesAutocompleteFormItem from 'view/periodicityTypes/autocomplete/PeriodicityTypesAutocompleteFormItem';
import TaskTemplatesAutocompleteFormItem from 'view/taskTemplates/autocomplete/TaskTemplatesAutocompleteFormItem';
import MaintenanceTemplatesAutocompleteFormItem from 'view/maintenanceTemplates/autocomplete/MaintenanceTemplatesAutocompleteFormItem';

const { fields } = model;

class MaintenanceTemplatesForm extends Component {
  schema = new FormSchema(fields.id, [
    fields.identifier,
    fields.name,
    fields.description,
    fields.maintenanceType,
    fields.priority,
    fields.version,
    fields.category,
    fields.periodicity,
    fields.duration,
    fields.isEvidenceRequired,
    fields.isSignatureRequired,
    fields.tasks,
    fields.relatedMaintenances,
  ]);

  handleSubmit = (values) => {
    const { id, ...data } = this.schema.cast(values);
    this.props.onSubmit(id, data);
  };

  initialValues = () => {
    const record = this.props.record;
    return this.schema.initialValues(record || {});
  };

  renderForm() {
    const { saveLoading, isEditing, modal } = this.props;

    return (
      <FormWrapper>
        <Formik
          initialValues={this.initialValues()}
          validationSchema={this.schema.schema}
          onSubmit={this.handleSubmit}
          render={(form) => {
            return (
              <form onSubmit={form.handleSubmit}>
                {isEditing && (
                  <ViewFormItem
                    name={fields.id.name}
                    label={fields.id.label}
                  />
                )}

                <InputFormItem
                  name={fields.identifier.name}
                  label={fields.identifier.label}
                  required={fields.identifier.required}
                  autoFocus
                />
                <InputFormItem
                  name={fields.name.name}
                  label={fields.name.label}
                  required={fields.name.required}
                />
                <TextAreaFormItem
                  name={fields.description.name}
                  label={fields.description.label}
                  required={fields.description.required}
                />
                <MaintenanceTypesAutocompleteFormItem
                  name={fields.maintenanceType.name}
                  label={fields.maintenanceType.label}
                  required={fields.maintenanceType.required}
                  showCreate={!this.props.modal}
                  form={form}
                />
                <SelectFormItem
                  name={fields.priority.name}
                  label={fields.priority.label}
                  options={fields.priority.options.map(
                    (item) => ({
                      value: item.id,
                      label: item.label,
                    }),
                  )}
                  required={fields.priority.required}
                />
                <InputNumberFormItem
                  name={fields.version.name}
                  label={fields.version.label}
                  required={
                    fields.version.required
                  }
                />
                <CategoryTypesAutocompleteFormItem
                  name={fields.category.name}
                  label={fields.category.label}
                  required={fields.category.required}
                  showCreate={!this.props.modal}
                  form={form}
                />
                <PeriodicityTypesAutocompleteFormItem
                  name={fields.periodicity.name}
                  label={fields.periodicity.label}
                  required={fields.periodicity.required}
                  showCreate={!this.props.modal}
                  form={form}
                />
                <InputFormItem
                  name={fields.duration.name}
                  label={fields.duration.label}
                  required={fields.duration.required}
                />
                <SwitchFormItem
                  name={fields.isEvidenceRequired.name}
                  label={fields.isEvidenceRequired.label}
                />
                <SwitchFormItem
                  name={fields.isSignatureRequired.name}
                  label={fields.isSignatureRequired.label}
                />
                <TaskTemplatesAutocompleteFormItem
                  name={fields.tasks.name}
                  label={fields.tasks.label}
                  required={fields.tasks.required}
                  showCreate={!this.props.modal}
                  form={form}
                  mode="multiple"
                />
                <MaintenanceTemplatesAutocompleteFormItem
                  name={fields.relatedMaintenances.name}
                  label={fields.relatedMaintenances.label}
                  required={fields.relatedMaintenances.required}
                  showCreate={!this.props.modal}
                  form={form}
                  mode="multiple"
                />

                <FormButtons
                  style={{
                    flexDirection: modal
                      ? 'row-reverse'
                      : undefined,
                  }}
                >
                  <Button
                    variant="contained"
                    color="primary"
                    disabled={saveLoading}
                    type="button"
                    onClick={form.handleSubmit}
                    startIcon={<SaveIcon />}
                  >
                    {i18n('common.save')}
                  </Button>

                  <Button
                    disabled={saveLoading}
                    onClick={form.handleReset}
                    type="button"
                    startIcon={<UndoIcon />}
                  >
                    {i18n('common.reset')}
                  </Button>

                  {this.props.onCancel ? (
                    <Button
                      disabled={saveLoading}
                      onClick={() => this.props.onCancel()}
                      type="button"
                      startIcon={<CloseIcon />}
                    >
                      {i18n('common.cancel')}
                    </Button>
                  ) : null}
                </FormButtons>
              </form>
            );
          }}
        />
      </FormWrapper>
    );
  }

  render() {
    const { isEditing, findLoading, record } = this.props;

    if (findLoading) {
      return <Spinner />;
    }

    if (isEditing && !record) {
      return <Spinner />;
    }

    return this.renderForm();
  }
}

export default MaintenanceTemplatesForm;
