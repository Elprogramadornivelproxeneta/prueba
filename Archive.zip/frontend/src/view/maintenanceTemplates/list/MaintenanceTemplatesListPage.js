import React, { Component } from 'react';
import MaintenanceTemplatesListFilter from 'view/maintenanceTemplates/list/MaintenanceTemplatesListFilter';
import MaintenanceTemplatesListTable from 'view/maintenanceTemplates/list/MaintenanceTemplatesListTable';
import MaintenanceTemplatesListToolbar from 'view/maintenanceTemplates/list/MaintenanceTemplatesListToolbar';
import ContentWrapper from 'view/layout/styles/ContentWrapper';
import PageTitle from 'view/shared/styles/PageTitle';
import Breadcrumb from 'view/shared/Breadcrumb';
import { i18n } from 'i18n';

class MaintenanceTemplatesListPage extends Component {
  render() {
    return (
      <React.Fragment>
        <Breadcrumb
          items={[
            [i18n('home.menu'), '/'],
            [i18n('entities.maintenanceTemplates.menu')],
          ]}
        />

        <ContentWrapper>
          <PageTitle>
            {i18n('entities.maintenanceTemplates.list.title')}
          </PageTitle>

          <MaintenanceTemplatesListToolbar />
          <MaintenanceTemplatesListFilter />
          <MaintenanceTemplatesListTable />
        </ContentWrapper>
      </React.Fragment>
    );
  }
}

export default MaintenanceTemplatesListPage;
