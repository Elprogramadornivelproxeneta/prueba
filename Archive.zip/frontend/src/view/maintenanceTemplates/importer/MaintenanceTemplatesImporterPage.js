import React, { Component } from 'react';
import ContentWrapper from 'view/layout/styles/ContentWrapper';
import PageTitle from 'view/shared/styles/PageTitle';
import Breadcrumb from 'view/shared/Breadcrumb';
import { i18n } from 'i18n';
import importerHoc from 'view/shared/importer/Importer';
import selectors from 'modules/maintenanceTemplates/importer/maintenanceTemplatesImporterSelectors';
import actions from 'modules/maintenanceTemplates/importer/maintenanceTemplatesImporterActions';
import fields from 'modules/maintenanceTemplates/importer/maintenanceTemplatesImporterFields';

class MaintenanceTemplatesImportPage extends Component {
  render() {
    const Importer = importerHoc(
      selectors,
      actions,
      fields,
      i18n('entities.maintenanceTemplates.importer.hint'),
    );

    return (
      <React.Fragment>
        <Breadcrumb
          items={[
            [i18n('home.menu'), '/'],
            [
              i18n('entities.maintenanceTemplates.menu'),
              '/maintenance-templates',
            ],
            [
              i18n(
                'entities.maintenanceTemplates.importer.title',
              ),
            ],
          ]}
        />

        <ContentWrapper>
          <PageTitle>
            {i18n(
              'entities.maintenanceTemplates.importer.title',
            )}
          </PageTitle>

          <Importer />
        </ContentWrapper>
      </React.Fragment>
    );
  }
}

export default MaintenanceTemplatesImportPage;
