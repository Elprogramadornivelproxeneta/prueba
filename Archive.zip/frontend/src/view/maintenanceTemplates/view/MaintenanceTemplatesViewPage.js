import React, { Component } from 'react';
import ContentWrapper from 'view/layout/styles/ContentWrapper';
import PageTitle from 'view/shared/styles/PageTitle';
import Breadcrumb from 'view/shared/Breadcrumb';
import MaintenanceTemplatesView from 'view/maintenanceTemplates/view/MaintenanceTemplatesView';
import { i18n } from 'i18n';
import actions from 'modules/maintenanceTemplates/view/maintenanceTemplatesViewActions';
import { connect } from 'react-redux';
import selectors from 'modules/maintenanceTemplates/view/maintenanceTemplatesViewSelectors';
import MaintenanceTemplatesViewToolbar from 'view/maintenanceTemplates/view/MaintenanceTemplatesViewToolbar';

class MaintenanceTemplatesPage extends Component {
  componentDidMount() {
    const { dispatch, match } = this.props;
    dispatch(actions.doFind(match.params.id));
  }

  render() {
    return (
      <React.Fragment>
        <Breadcrumb
          items={[
            [i18n('home.menu'), '/'],
            [i18n('entities.maintenanceTemplates.menu'), '/maintenance-templates'],
            [i18n('entities.maintenanceTemplates.view.title')],
          ]}
        />

        <ContentWrapper>
          <PageTitle>
            {i18n('entities.maintenanceTemplates.view.title')}
          </PageTitle>

          <MaintenanceTemplatesViewToolbar match={this.props.match} />

          <MaintenanceTemplatesView
            loading={this.props.loading}
            record={this.props.record}
          />
        </ContentWrapper>
      </React.Fragment>
    );
  }
}

function select(state) {
  return {
    loading: selectors.selectLoading(state),
    record: selectors.selectRecord(state),
  };
}

export default connect(select)(MaintenanceTemplatesPage);
