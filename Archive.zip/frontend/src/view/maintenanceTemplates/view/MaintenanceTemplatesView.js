import model from 'modules/maintenanceTemplates/maintenanceTemplatesModel';
import React, { Component } from 'react';
import Spinner from 'view/shared/Spinner';
import TextViewItem from 'view/shared/view/TextViewItem';
import MaintenanceTypesViewItem from 'view/maintenanceTypes/view/MaintenanceTypesViewItem';
import CategoryTypesViewItem from 'view/categoryTypes/view/CategoryTypesViewItem';
import PeriodicityTypesViewItem from 'view/periodicityTypes/view/PeriodicityTypesViewItem';
import TaskTemplatesViewItem from 'view/taskTemplates/view/TaskTemplatesViewItem';
import MaintenanceTemplatesViewItem from 'view/maintenanceTemplates/view/MaintenanceTemplatesViewItem';

const { fields } = model;

class MaintenanceTemplatesView extends Component {
  renderView() {
    const { record } = this.props;

    return (
      <div>
        <TextViewItem
          label={fields.id.label}
          value={fields.id.forView(record.id)}
        />

        <TextViewItem
          label={fields.identifier.label}
          value={fields.identifier.forView(record.identifier)}
        />

        <TextViewItem
          label={fields.name.label}
          value={fields.name.forView(record.name)}
        />

        <TextViewItem
          label={fields.description.label}
          value={fields.description.forView(record.description)}
        />

        <MaintenanceTypesViewItem
          label={fields.maintenanceType.label}
          value={fields.maintenanceType.forView(record.maintenanceType)}
        />

        <TextViewItem
          label={fields.priority.label}
          value={fields.priority.forView(record.priority)}
        />

        <TextViewItem
          label={fields.version.label}
          value={fields.version.forView(record.version)}
        />

        <CategoryTypesViewItem
          label={fields.category.label}
          value={fields.category.forView(record.category)}
        />

        <PeriodicityTypesViewItem
          label={fields.periodicity.label}
          value={fields.periodicity.forView(record.periodicity)}
        />

        <TextViewItem
          label={fields.duration.label}
          value={fields.duration.forView(record.duration)}
        />

        <TextViewItem
          label={fields.isEvidenceRequired.label}
          value={fields.isEvidenceRequired.forView(record.isEvidenceRequired)}
        />

        <TextViewItem
          label={fields.isSignatureRequired.label}
          value={fields.isSignatureRequired.forView(record.isSignatureRequired)}
        />

        <TaskTemplatesViewItem
          label={fields.tasks.label}
          value={fields.tasks.forView(record.tasks)}
        />

        <MaintenanceTemplatesViewItem
          label={fields.relatedMaintenances.label}
          value={fields.relatedMaintenances.forView(record.relatedMaintenances)}
        />

        <TextViewItem
          label={fields.createdAt.label}
          value={fields.createdAt.forView(record.createdAt)}
        />

        <TextViewItem
          label={fields.updatedAt.label}
          value={fields.updatedAt.forView(record.updatedAt)}
        />
      </div>
    );
  }

  render() {
    const { record, loading } = this.props;

    if (loading || !record) {
      return <Spinner />;
    }

    return this.renderView();
  }
}

export default MaintenanceTemplatesView;
