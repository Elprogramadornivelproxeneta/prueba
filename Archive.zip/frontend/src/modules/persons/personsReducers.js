import list from 'modules/persons/list/personsListReducers';
import form from 'modules/persons/form/personsFormReducers';
import view from 'modules/persons/view/personsViewReducers';
import destroy from 'modules/persons/destroy/personsDestroyReducers';
import importerReducer from 'modules/persons/importer/personsImporterReducers';
import { combineReducers } from 'redux';

export default combineReducers({
  list,
  form,
  view,
  destroy,
  importer: importerReducer,
});
