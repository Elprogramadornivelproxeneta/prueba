import { i18n } from 'i18n';
import IdField from 'modules/shared/fields/idField';
import DateTimeField from 'modules/shared/fields/dateTimeField';
import DateTimeRangeField from 'modules/shared/fields/dateTimeRangeField';
import StringField from 'modules/shared/fields/stringField';
import EnumeratorField from 'modules/shared/fields/enumeratorField';
import DateField from 'modules/shared/fields/dateField';
import DateRangeField from 'modules/shared/fields/dateRangeField';
import RelationToOneField from 'modules/shared/fields/relationToOneField';
import RelationToManyField from 'modules/shared/fields/relationToManyField';
import ImagesField from 'modules/shared/fields/imagesField';

function label(name) {
  return i18n(`entities.persons.fields.${name}`);
}

function enumeratorLabel(name, value) {
  return i18n(`entities.persons.enumerators.${name}.${value}`);
}

const fields = {
  id: new IdField('id', label('id')),
  userId: new RelationToOneField('userId', label('userId'), {}),
  name: new StringField('name', label('name'), {
    "required": true,
    "min": 2,
    "max": 255
  }),
  paternalSurname: new StringField('paternalSurname', label('paternalSurname'), {
    "required": true,
    "min": 2,
    "max": 255
  }),
  maternalSurname: new StringField('maternalSurname', label('maternalSurname'), {
    "min": 2,
    "max": 255
  }),
  gender: new EnumeratorField('gender', label('gender'), [
    { id: 'male', label: enumeratorLabel('gender', 'male') },
    { id: 'female', label: enumeratorLabel('gender', 'female') },
  ],{}),
  birthdate: new DateField('birthdate', label('birthdate'), {}),
  rfc: new StringField('rfc', label('rfc'), {
    "min": 10,
    "max": 13
  }),
  curp: new StringField('curp', label('curp'), {
    "min": 18,
    "max": 18
  }),
  identityDocument: new ImagesField('identityDocument', label('identityDocument'), 'persons/identityDocument',{}),
  identityDocumentType: new EnumeratorField('identityDocumentType', label('identityDocumentType'), [
    { id: 'INE', label: enumeratorLabel('identityDocumentType', 'INE') },
    { id: 'Pasaporte', label: enumeratorLabel('identityDocumentType', 'Pasaporte') },
    { id: 'Licencia', label: enumeratorLabel('identityDocumentType', 'Licencia') },
  ],{}),
  stations: new RelationToManyField('stations', label('stations'), {}),
  createdAt: new DateTimeField(
    'createdAt',
    label('createdAt'),
  ),
  updatedAt: new DateTimeField(
    'updatedAt',
    label('updatedAt'),
  ),
  createdAtRange: new DateTimeRangeField(
    'createdAtRange',
    label('createdAtRange'),
  ),
  birthdateRange: new DateRangeField(
    'birthdateRange',
    label('birthdateRange'),
  ),
};

export default {
  fields,
};
