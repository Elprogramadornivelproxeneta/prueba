import list from 'modules/productReception/list/productReceptionListReducers';
import form from 'modules/productReception/form/productReceptionFormReducers';
import view from 'modules/productReception/view/productReceptionViewReducers';
import destroy from 'modules/productReception/destroy/productReceptionDestroyReducers';
import importerReducer from 'modules/productReception/importer/productReceptionImporterReducers';
import { combineReducers } from 'redux';

export default combineReducers({
  list,
  form,
  view,
  destroy,
  importer: importerReducer,
});
