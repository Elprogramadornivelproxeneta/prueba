import { i18n } from 'i18n';
import IdField from 'modules/shared/fields/idField';
import DateTimeField from 'modules/shared/fields/dateTimeField';
import DateTimeRangeField from 'modules/shared/fields/dateTimeRangeField';
import StringField from 'modules/shared/fields/stringField';
import DecimalRangeField from 'modules/shared/fields/decimalRangeField';
import DecimalField from 'modules/shared/fields/decimalField';
import RelationToOneField from 'modules/shared/fields/relationToOneField';

function label(name) {
  return i18n(`entities.productReception.fields.${name}`);
}

const fields = {
  id: new IdField('id', label('id')),
  referral: new StringField('referral', label('referral'), {}),
  tank: new RelationToOneField('tank', label('tank'), {}),
  quantity: new DecimalField('quantity', label('quantity'), {}),
  startTime: new DateTimeField('startTime', label('startTime'), {}),
  endTime: new DateTimeField('endTime', label('endTime'), {}),
  createdAt: new DateTimeField(
    'createdAt',
    label('createdAt'),
  ),
  updatedAt: new DateTimeField(
    'updatedAt',
    label('updatedAt'),
  ),
  createdAtRange: new DateTimeRangeField(
    'createdAtRange',
    label('createdAtRange'),
  ),
  quantityRange: new DecimalRangeField(
    'quantityRange',
    label('quantityRange'),
  ),
  startTimeRange: new DateTimeRangeField(
    'startTimeRange',
    label('startTimeRange'),
  ),
  endTimeRange: new DateTimeRangeField(
    'endTimeRange',
    label('endTimeRange'),
  ),
};

export default {
  fields,
};
