import { i18n } from 'i18n';
import IdField from 'modules/shared/fields/idField';
import DateTimeField from 'modules/shared/fields/dateTimeField';
import DateTimeRangeField from 'modules/shared/fields/dateTimeRangeField';
import StringField from 'modules/shared/fields/stringField';
import EnumeratorField from 'modules/shared/fields/enumeratorField';

function label(name) {
  return i18n(`entities.addresses.fields.${name}`);
}

function enumeratorLabel(name, value) {
  return i18n(`entities.addresses.enumerators.${name}.${value}`);
}

const fields = {
  id: new IdField('id', label('id')),
  addressLine1: new StringField('addressLine1', label('addressLine1'), {
    "required": true
  }),
  addressLine2: new StringField('addressLine2', label('addressLine2'), {}),
  postalCode: new StringField('postalCode', label('postalCode'), {
    "required": true,
    "min": 5,
    "max": 5
  }),
  colony: new StringField('colony', label('colony'), {}),
  municipality: new StringField('municipality', label('municipality'), {
    "required": true
  }),
  state: new EnumeratorField('state', label('state'), [
    { id: 'AGS', label: enumeratorLabel('state', 'AGS') },
    { id: 'CDMX', label: enumeratorLabel('state', 'CDMX') },
  ],{}),
  createdAt: new DateTimeField(
    'createdAt',
    label('createdAt'),
  ),
  updatedAt: new DateTimeField(
    'updatedAt',
    label('updatedAt'),
  ),
  createdAtRange: new DateTimeRangeField(
    'createdAtRange',
    label('createdAtRange'),
  ),

};

export default {
  fields,
};
