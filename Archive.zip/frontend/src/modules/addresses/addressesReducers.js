import list from 'modules/addresses/list/addressesListReducers';
import form from 'modules/addresses/form/addressesFormReducers';
import view from 'modules/addresses/view/addressesViewReducers';
import destroy from 'modules/addresses/destroy/addressesDestroyReducers';
import importerReducer from 'modules/addresses/importer/addressesImporterReducers';
import { combineReducers } from 'redux';

export default combineReducers({
  list,
  form,
  view,
  destroy,
  importer: importerReducer,
});
