import list from 'modules/periodicityTypes/list/periodicityTypesListReducers';
import form from 'modules/periodicityTypes/form/periodicityTypesFormReducers';
import view from 'modules/periodicityTypes/view/periodicityTypesViewReducers';
import destroy from 'modules/periodicityTypes/destroy/periodicityTypesDestroyReducers';
import importerReducer from 'modules/periodicityTypes/importer/periodicityTypesImporterReducers';
import { combineReducers } from 'redux';

export default combineReducers({
  list,
  form,
  view,
  destroy,
  importer: importerReducer,
});
