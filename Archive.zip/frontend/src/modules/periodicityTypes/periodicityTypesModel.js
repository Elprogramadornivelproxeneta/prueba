import { i18n } from 'i18n';
import IdField from 'modules/shared/fields/idField';
import DateTimeField from 'modules/shared/fields/dateTimeField';
import DateTimeRangeField from 'modules/shared/fields/dateTimeRangeField';
import IntegerField from 'modules/shared/fields/integerField';
import IntegerRangeField from 'modules/shared/fields/integerRangeField';
import StringField from 'modules/shared/fields/stringField';

function label(name) {
  return i18n(`entities.periodicityTypes.fields.${name}`);
}

const fields = {
  id: new IdField('id', label('id')),
  order: new IntegerField('order', label('order'), {
    "min": 1,
    "required": true,
    "max": 100
  }),
  name: new StringField('name', label('name'), {
    "required": true
  }),
  increment: new IntegerField('increment', label('increment'), {
    "required": true,
    "min": 1
  }),
  unit: new StringField('unit', label('unit'), {
    "required": true
  }),
  createdAt: new DateTimeField(
    'createdAt',
    label('createdAt'),
  ),
  updatedAt: new DateTimeField(
    'updatedAt',
    label('updatedAt'),
  ),
  createdAtRange: new DateTimeRangeField(
    'createdAtRange',
    label('createdAtRange'),
  ),
  orderRange: new IntegerRangeField(
    'orderRange',
    label('orderRange'),
  ),
  incrementRange: new IntegerRangeField(
    'incrementRange',
    label('incrementRange'),
  ),
};

export default {
  fields,
};
