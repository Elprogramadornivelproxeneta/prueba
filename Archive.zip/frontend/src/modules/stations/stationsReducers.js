import list from 'modules/stations/list/stationsListReducers';
import form from 'modules/stations/form/stationsFormReducers';
import view from 'modules/stations/view/stationsViewReducers';
import destroy from 'modules/stations/destroy/stationsDestroyReducers';
import importerReducer from 'modules/stations/importer/stationsImporterReducers';
import { combineReducers } from 'redux';

export default combineReducers({
  list,
  form,
  view,
  destroy,
  importer: importerReducer,
});
