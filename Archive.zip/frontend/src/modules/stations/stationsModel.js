import { i18n } from 'i18n';
import IdField from 'modules/shared/fields/idField';
import DateTimeField from 'modules/shared/fields/dateTimeField';
import DateTimeRangeField from 'modules/shared/fields/dateTimeRangeField';
import StringField from 'modules/shared/fields/stringField';
import RelationToOneField from 'modules/shared/fields/relationToOneField';
import RelationToManyField from 'modules/shared/fields/relationToManyField';

function label(name) {
  return i18n(`entities.stations.fields.${name}`);
}

const fields = {
  id: new IdField('id', label('id')),
  identifier: new StringField('identifier', label('identifier'), {
    "required": true,
    "max": 50
  }),
  name: new StringField('name', label('name'), {
    "required": true
  }),
  address: new RelationToOneField('address', label('address'), {
    "required": true
  }),
  legalRepresentative: new RelationToOneField('legalRepresentative', label('legalRepresentative'), {}),
  users: new RelationToManyField('users', label('users'), {}),
  maintenanceTemplates: new RelationToManyField('maintenanceTemplates', label('maintenanceTemplates'), {}),
  tanks: new RelationToManyField('tanks', label('tanks'), {}),
  createdAt: new DateTimeField(
    'createdAt',
    label('createdAt'),
  ),
  updatedAt: new DateTimeField(
    'updatedAt',
    label('updatedAt'),
  ),
  createdAtRange: new DateTimeRangeField(
    'createdAtRange',
    label('createdAtRange'),
  ),

};

export default {
  fields,
};
