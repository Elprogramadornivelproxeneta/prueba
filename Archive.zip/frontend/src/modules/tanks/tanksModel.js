import { i18n } from 'i18n';
import IdField from 'modules/shared/fields/idField';
import DateTimeField from 'modules/shared/fields/dateTimeField';
import DateTimeRangeField from 'modules/shared/fields/dateTimeRangeField';
import IntegerField from 'modules/shared/fields/integerField';
import IntegerRangeField from 'modules/shared/fields/integerRangeField';
import DecimalRangeField from 'modules/shared/fields/decimalRangeField';
import DecimalField from 'modules/shared/fields/decimalField';
import RelationToOneField from 'modules/shared/fields/relationToOneField';

function label(name) {
  return i18n(`entities.tanks.fields.${name}`);
}

const fields = {
  id: new IdField('id', label('id')),
  tankNumber: new IntegerField('tankNumber', label('tankNumber'), {
    "required": true,
    "min": 1,
    "max": 100
  }),
  fuelType: new RelationToOneField('fuelType', label('fuelType'), {}),
  volume: new DecimalField('volume', label('volume'), {}),
  station: new RelationToOneField('station', label('station'), {}),
  createdAt: new DateTimeField(
    'createdAt',
    label('createdAt'),
  ),
  updatedAt: new DateTimeField(
    'updatedAt',
    label('updatedAt'),
  ),
  createdAtRange: new DateTimeRangeField(
    'createdAtRange',
    label('createdAtRange'),
  ),
  tankNumberRange: new IntegerRangeField(
    'tankNumberRange',
    label('tankNumberRange'),
  ),
  volumeRange: new DecimalRangeField(
    'volumeRange',
    label('volumeRange'),
  ),
};

export default {
  fields,
};
