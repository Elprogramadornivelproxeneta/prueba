import list from 'modules/tanks/list/tanksListReducers';
import form from 'modules/tanks/form/tanksFormReducers';
import view from 'modules/tanks/view/tanksViewReducers';
import destroy from 'modules/tanks/destroy/tanksDestroyReducers';
import importerReducer from 'modules/tanks/importer/tanksImporterReducers';
import { combineReducers } from 'redux';

export default combineReducers({
  list,
  form,
  view,
  destroy,
  importer: importerReducer,
});
