import list from 'modules/maintenanceTypes/list/maintenanceTypesListReducers';
import form from 'modules/maintenanceTypes/form/maintenanceTypesFormReducers';
import view from 'modules/maintenanceTypes/view/maintenanceTypesViewReducers';
import destroy from 'modules/maintenanceTypes/destroy/maintenanceTypesDestroyReducers';
import importerReducer from 'modules/maintenanceTypes/importer/maintenanceTypesImporterReducers';
import { combineReducers } from 'redux';

export default combineReducers({
  list,
  form,
  view,
  destroy,
  importer: importerReducer,
});
