import list from 'modules/fuelTypes/list/fuelTypesListReducers';
import form from 'modules/fuelTypes/form/fuelTypesFormReducers';
import view from 'modules/fuelTypes/view/fuelTypesViewReducers';
import destroy from 'modules/fuelTypes/destroy/fuelTypesDestroyReducers';
import importerReducer from 'modules/fuelTypes/importer/fuelTypesImporterReducers';
import { combineReducers } from 'redux';

export default combineReducers({
  list,
  form,
  view,
  destroy,
  importer: importerReducer,
});
