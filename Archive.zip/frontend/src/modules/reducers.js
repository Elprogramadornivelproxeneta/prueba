import { connectRouter } from 'connected-react-router';
import layout from 'modules/layout/layoutReducers';
import auth from 'modules/auth/authReducers';
import iam from 'modules/iam/iamReducers';
import auditLog from 'modules/auditLog/auditLogReducers';
import settings from 'modules/settings/settingsReducers';
import persons from 'modules/persons/personsReducers';
import stations from 'modules/stations/stationsReducers';
import addresses from 'modules/addresses/addressesReducers';
import maintenanceTemplates from 'modules/maintenanceTemplates/maintenanceTemplatesReducers';
import categoryTypes from 'modules/categoryTypes/categoryTypesReducers';
import taskTemplates from 'modules/taskTemplates/taskTemplatesReducers';
import workOrders from 'modules/workOrders/workOrdersReducers';
import tasks from 'modules/tasks/tasksReducers';
import maintenanceTypes from 'modules/maintenanceTypes/maintenanceTypesReducers';
import periodicityTypes from 'modules/periodicityTypes/periodicityTypesReducers';
import fuelTypes from 'modules/fuelTypes/fuelTypesReducers';
import tanks from 'modules/tanks/tanksReducers';
import productReception from 'modules/productReception/productReceptionReducers';
import productDeviation from 'modules/productDeviation/productDeviationReducers';
import { combineReducers } from 'redux';

export default (history) =>
  combineReducers({
    router: connectRouter(history),
    layout,
    auth,
    iam,
    auditLog,
    settings,
    persons,
    stations,
    addresses,
    maintenanceTemplates,
    categoryTypes,
    taskTemplates,
    workOrders,
    tasks,
    maintenanceTypes,
    periodicityTypes,
    fuelTypes,
    tanks,
    productReception,
    productDeviation,
  });
