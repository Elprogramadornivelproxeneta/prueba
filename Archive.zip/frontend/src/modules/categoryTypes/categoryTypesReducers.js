import list from 'modules/categoryTypes/list/categoryTypesListReducers';
import form from 'modules/categoryTypes/form/categoryTypesFormReducers';
import view from 'modules/categoryTypes/view/categoryTypesViewReducers';
import destroy from 'modules/categoryTypes/destroy/categoryTypesDestroyReducers';
import importerReducer from 'modules/categoryTypes/importer/categoryTypesImporterReducers';
import { combineReducers } from 'redux';

export default combineReducers({
  list,
  form,
  view,
  destroy,
  importer: importerReducer,
});
