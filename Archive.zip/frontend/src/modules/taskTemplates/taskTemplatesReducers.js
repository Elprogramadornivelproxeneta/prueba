import list from 'modules/taskTemplates/list/taskTemplatesListReducers';
import form from 'modules/taskTemplates/form/taskTemplatesFormReducers';
import view from 'modules/taskTemplates/view/taskTemplatesViewReducers';
import destroy from 'modules/taskTemplates/destroy/taskTemplatesDestroyReducers';
import importerReducer from 'modules/taskTemplates/importer/taskTemplatesImporterReducers';
import { combineReducers } from 'redux';

export default combineReducers({
  list,
  form,
  view,
  destroy,
  importer: importerReducer,
});
