import { i18n } from 'i18n';
import IdField from 'modules/shared/fields/idField';
import DateTimeField from 'modules/shared/fields/dateTimeField';
import DateTimeRangeField from 'modules/shared/fields/dateTimeRangeField';
import IntegerField from 'modules/shared/fields/integerField';
import IntegerRangeField from 'modules/shared/fields/integerRangeField';
import StringField from 'modules/shared/fields/stringField';
import BooleanField from 'modules/shared/fields/booleanField';
import RelationToOneField from 'modules/shared/fields/relationToOneField';

function label(name) {
  return i18n(`entities.taskTemplates.fields.${name}`);
}

const fields = {
  id: new IdField('id', label('id')),
  order: new IntegerField('order', label('order'), {
    "required": true,
    "min": 1,
    "max": 100
  }),
  name: new StringField('name', label('name'), {
    "required": true,
    "min": 5,
    "max": 255
  }),
  description: new StringField('description', label('description'), {
    "max": 1000
  }),
  isEvidenceRequired: new BooleanField('isEvidenceRequired', label('isEvidenceRequired')),
  maintenanceTemplateId: new RelationToOneField('maintenanceTemplateId', label('maintenanceTemplateId'), {}),
  createdAt: new DateTimeField(
    'createdAt',
    label('createdAt'),
  ),
  updatedAt: new DateTimeField(
    'updatedAt',
    label('updatedAt'),
  ),
  createdAtRange: new DateTimeRangeField(
    'createdAtRange',
    label('createdAtRange'),
  ),
  orderRange: new IntegerRangeField(
    'orderRange',
    label('orderRange'),
  ),
};

export default {
  fields,
};
