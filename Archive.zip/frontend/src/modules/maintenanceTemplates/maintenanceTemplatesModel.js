import { i18n } from 'i18n';
import IdField from 'modules/shared/fields/idField';
import DateTimeField from 'modules/shared/fields/dateTimeField';
import DateTimeRangeField from 'modules/shared/fields/dateTimeRangeField';
import IntegerField from 'modules/shared/fields/integerField';
import IntegerRangeField from 'modules/shared/fields/integerRangeField';
import StringField from 'modules/shared/fields/stringField';
import EnumeratorField from 'modules/shared/fields/enumeratorField';
import BooleanField from 'modules/shared/fields/booleanField';
import RelationToOneField from 'modules/shared/fields/relationToOneField';
import RelationToManyField from 'modules/shared/fields/relationToManyField';

function label(name) {
  return i18n(`entities.maintenanceTemplates.fields.${name}`);
}

function enumeratorLabel(name, value) {
  return i18n(`entities.maintenanceTemplates.enumerators.${name}.${value}`);
}

const fields = {
  id: new IdField('id', label('id')),
  identifier: new StringField('identifier', label('identifier'), {
    "required": true,
    "min": 3,
    "max": 20
  }),
  name: new StringField('name', label('name'), {
    "required": true,
    "min": 2,
    "max": 255
  }),
  description: new StringField('description', label('description'), {
    "max": 1024
  }),
  maintenanceType: new RelationToOneField('maintenanceType', label('maintenanceType'), {}),
  priority: new EnumeratorField('priority', label('priority'), [
    { id: 'Alta', label: enumeratorLabel('priority', 'Alta') },
    { id: 'Media', label: enumeratorLabel('priority', 'Media') },
    { id: 'Baja', label: enumeratorLabel('priority', 'Baja') },
  ],{
    "required": true
  }),
  version: new IntegerField('version', label('version'), {
    "required": true
  }),
  category: new RelationToOneField('category', label('category'), {}),
  periodicity: new RelationToOneField('periodicity', label('periodicity'), {}),
  duration: new StringField('duration', label('duration'), {
    "required": true,
    "max": 5
  }),
  isEvidenceRequired: new BooleanField('isEvidenceRequired', label('isEvidenceRequired')),
  isSignatureRequired: new BooleanField('isSignatureRequired', label('isSignatureRequired')),
  tasks: new RelationToManyField('tasks', label('tasks'), {}),
  relatedMaintenances: new RelationToManyField('relatedMaintenances', label('relatedMaintenances'), {}),
  createdAt: new DateTimeField(
    'createdAt',
    label('createdAt'),
  ),
  updatedAt: new DateTimeField(
    'updatedAt',
    label('updatedAt'),
  ),
  createdAtRange: new DateTimeRangeField(
    'createdAtRange',
    label('createdAtRange'),
  ),
  versionRange: new IntegerRangeField(
    'versionRange',
    label('versionRange'),
  ),
};

export default {
  fields,
};
