import list from 'modules/maintenanceTemplates/list/maintenanceTemplatesListReducers';
import form from 'modules/maintenanceTemplates/form/maintenanceTemplatesFormReducers';
import view from 'modules/maintenanceTemplates/view/maintenanceTemplatesViewReducers';
import destroy from 'modules/maintenanceTemplates/destroy/maintenanceTemplatesDestroyReducers';
import importerReducer from 'modules/maintenanceTemplates/importer/maintenanceTemplatesImporterReducers';
import { combineReducers } from 'redux';

export default combineReducers({
  list,
  form,
  view,
  destroy,
  importer: importerReducer,
});
