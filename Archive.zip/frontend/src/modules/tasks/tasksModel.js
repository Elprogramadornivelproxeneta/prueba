import { i18n } from 'i18n';
import IdField from 'modules/shared/fields/idField';
import DateTimeField from 'modules/shared/fields/dateTimeField';
import DateTimeRangeField from 'modules/shared/fields/dateTimeRangeField';
import StringField from 'modules/shared/fields/stringField';
import EnumeratorField from 'modules/shared/fields/enumeratorField';
import RelationToOneField from 'modules/shared/fields/relationToOneField';
import ImagesField from 'modules/shared/fields/imagesField';

function label(name) {
  return i18n(`entities.tasks.fields.${name}`);
}

function enumeratorLabel(name, value) {
  return i18n(`entities.tasks.enumerators.${name}.${value}`);
}

const fields = {
  id: new IdField('id', label('id')),
  result: new EnumeratorField('result', label('result'), [
    { id: 'VALID', label: enumeratorLabel('result', 'VALID') },
    { id: 'INVALID', label: enumeratorLabel('result', 'INVALID') },
  ],{}),
  evidences: new ImagesField('evidences', label('evidences'), 'tasks/evidences',{}),
  workOrderId: new RelationToOneField('workOrderId', label('workOrderId'), {}),
  taskTemplateId: new RelationToOneField('taskTemplateId', label('taskTemplateId'), {}),
  name: new StringField('name', label('name'), {
    "required": true
  }),
  createdAt: new DateTimeField(
    'createdAt',
    label('createdAt'),
  ),
  updatedAt: new DateTimeField(
    'updatedAt',
    label('updatedAt'),
  ),
  createdAtRange: new DateTimeRangeField(
    'createdAtRange',
    label('createdAtRange'),
  ),

};

export default {
  fields,
};
