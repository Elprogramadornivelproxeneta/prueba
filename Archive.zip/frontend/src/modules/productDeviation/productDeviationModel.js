import { i18n } from 'i18n';
import IdField from 'modules/shared/fields/idField';
import DateTimeField from 'modules/shared/fields/dateTimeField';
import DateTimeRangeField from 'modules/shared/fields/dateTimeRangeField';
import DecimalRangeField from 'modules/shared/fields/decimalRangeField';
import DecimalField from 'modules/shared/fields/decimalField';
import RelationToOneField from 'modules/shared/fields/relationToOneField';

function label(name) {
  return i18n(`entities.productDeviation.fields.${name}`);
}

const fields = {
  id: new IdField('id', label('id')),
  tank: new RelationToOneField('tank', label('tank'), {}),
  initialInventoryVedeer: new DecimalField('initialInventoryVedeer', label('initialInventoryVedeer'), {
    "required": true
  }),
  finalInventoryVedeer: new DecimalField('finalInventoryVedeer', label('finalInventoryVedeer'), {}),
  volumePurchased: new DecimalField('volumePurchased', label('volumePurchased'), {}),
  volumeSold: new DecimalField('volumeSold', label('volumeSold'), {}),
  finalPhysicalInventory: new DecimalField('finalPhysicalInventory', label('finalPhysicalInventory'), {}),
  difference: new DecimalField('difference', label('difference'), {}),
  createdAt: new DateTimeField(
    'createdAt',
    label('createdAt'),
  ),
  updatedAt: new DateTimeField(
    'updatedAt',
    label('updatedAt'),
  ),
  createdAtRange: new DateTimeRangeField(
    'createdAtRange',
    label('createdAtRange'),
  ),
  initialInventoryVedeerRange: new DecimalRangeField(
    'initialInventoryVedeerRange',
    label('initialInventoryVedeerRange'),
  ),
  finalInventoryVedeerRange: new DecimalRangeField(
    'finalInventoryVedeerRange',
    label('finalInventoryVedeerRange'),
  ),
  volumePurchasedRange: new DecimalRangeField(
    'volumePurchasedRange',
    label('volumePurchasedRange'),
  ),
  volumeSoldRange: new DecimalRangeField(
    'volumeSoldRange',
    label('volumeSoldRange'),
  ),
  finalPhysicalInventoryRange: new DecimalRangeField(
    'finalPhysicalInventoryRange',
    label('finalPhysicalInventoryRange'),
  ),
  differenceRange: new DecimalRangeField(
    'differenceRange',
    label('differenceRange'),
  ),
};

export default {
  fields,
};
