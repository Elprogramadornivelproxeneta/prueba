import list from 'modules/productDeviation/list/productDeviationListReducers';
import form from 'modules/productDeviation/form/productDeviationFormReducers';
import view from 'modules/productDeviation/view/productDeviationViewReducers';
import destroy from 'modules/productDeviation/destroy/productDeviationDestroyReducers';
import importerReducer from 'modules/productDeviation/importer/productDeviationImporterReducers';
import { combineReducers } from 'redux';

export default combineReducers({
  list,
  form,
  view,
  destroy,
  importer: importerReducer,
});
