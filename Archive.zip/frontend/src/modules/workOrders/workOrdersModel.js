import { i18n } from 'i18n';
import IdField from 'modules/shared/fields/idField';
import DateTimeField from 'modules/shared/fields/dateTimeField';
import DateTimeRangeField from 'modules/shared/fields/dateTimeRangeField';
import IntegerField from 'modules/shared/fields/integerField';
import IntegerRangeField from 'modules/shared/fields/integerRangeField';
import StringField from 'modules/shared/fields/stringField';
import EnumeratorField from 'modules/shared/fields/enumeratorField';
import DateField from 'modules/shared/fields/dateField';
import DateRangeField from 'modules/shared/fields/dateRangeField';
import RelationToOneField from 'modules/shared/fields/relationToOneField';
import RelationToManyField from 'modules/shared/fields/relationToManyField';
import FilesField from 'modules/shared/fields/filesField';
import ImagesField from 'modules/shared/fields/imagesField';

function label(name) {
  return i18n(`entities.workOrders.fields.${name}`);
}

function enumeratorLabel(name, value) {
  return i18n(`entities.workOrders.enumerators.${name}.${value}`);
}

const fields = {
  id: new IdField('id', label('id')),
  station: new RelationToOneField('station', label('station'), {}),
  maintenanceTemplate: new RelationToOneField('maintenanceTemplate', label('maintenanceTemplate'), {}),
  title: new StringField('title', label('title'), {}),
  status: new EnumeratorField('status', label('status'), [
    { id: 'PENDING', label: enumeratorLabel('status', 'PENDING') },
    { id: 'ASSIGNED', label: enumeratorLabel('status', 'ASSIGNED') },
    { id: 'IN_PROGRESS', label: enumeratorLabel('status', 'IN_PROGRESS') },
    { id: 'DONE', label: enumeratorLabel('status', 'DONE') },
  ],{
    "required": true
  }),
  plannedStartOn: new DateField('plannedStartOn', label('plannedStartOn'), {
    "required": true
  }),
  actualStartOn: new DateTimeField('actualStartOn', label('actualStartOn'), {}),
  finishedOn: new DateTimeField('finishedOn', label('finishedOn'), {}),
  duration: new IntegerField('duration', label('duration'), {}),
  operator: new RelationToOneField('operator', label('operator'), {}),
  tasks: new RelationToManyField('tasks', label('tasks'), {}),
  files: new FilesField('files', label('files'), 'workOrders/files',{}),
  signature: new ImagesField('signature', label('signature'), 'workOrders/signature',{}),
  evidences: new ImagesField('evidences', label('evidences'), 'workOrders/evidences',{}),
  createdAt: new DateTimeField(
    'createdAt',
    label('createdAt'),
  ),
  updatedAt: new DateTimeField(
    'updatedAt',
    label('updatedAt'),
  ),
  createdAtRange: new DateTimeRangeField(
    'createdAtRange',
    label('createdAtRange'),
  ),
  plannedStartOnRange: new DateRangeField(
    'plannedStartOnRange',
    label('plannedStartOnRange'),
  ),
  actualStartOnRange: new DateTimeRangeField(
    'actualStartOnRange',
    label('actualStartOnRange'),
  ),
  finishedOnRange: new DateTimeRangeField(
    'finishedOnRange',
    label('finishedOnRange'),
  ),
  durationRange: new IntegerRangeField(
    'durationRange',
    label('durationRange'),
  ),
};

export default {
  fields,
};
