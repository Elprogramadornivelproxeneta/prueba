import list from 'modules/workOrders/list/workOrdersListReducers';
import form from 'modules/workOrders/form/workOrdersFormReducers';
import view from 'modules/workOrders/view/workOrdersViewReducers';
import destroy from 'modules/workOrders/destroy/workOrdersDestroyReducers';
import importerReducer from 'modules/workOrders/importer/workOrdersImporterReducers';
import { combineReducers } from 'redux';

export default combineReducers({
  list,
  form,
  view,
  destroy,
  importer: importerReducer,
});
