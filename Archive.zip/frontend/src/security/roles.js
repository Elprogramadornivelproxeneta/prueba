import { i18n } from 'i18n';
import _values from 'lodash/values';

class Roles {
  static get values() {
    return {
      owner: 'owner',
      editor: 'editor',
      viewer: 'viewer',
      adminViewer: 'adminViewer',
      auditLogViewer: 'auditLogViewer',
      iamSecurityReviewer: 'iamSecurityReviewer',
      entityEditor: 'entityEditor',
      entityViewer: 'entityViewer',
      personsEditor: 'personsEditor',
      personsViewer: 'personsViewer',
      stationsEditor: 'stationsEditor',
      stationsViewer: 'stationsViewer',
      addressesEditor: 'addressesEditor',
      addressesViewer: 'addressesViewer',
      maintenanceTemplatesEditor: 'maintenanceTemplatesEditor',
      maintenanceTemplatesViewer: 'maintenanceTemplatesViewer',
      categoryTypesEditor: 'categoryTypesEditor',
      categoryTypesViewer: 'categoryTypesViewer',
      taskTemplatesEditor: 'taskTemplatesEditor',
      taskTemplatesViewer: 'taskTemplatesViewer',
      workOrdersEditor: 'workOrdersEditor',
      workOrdersViewer: 'workOrdersViewer',
      tasksEditor: 'tasksEditor',
      tasksViewer: 'tasksViewer',
      maintenanceTypesEditor: 'maintenanceTypesEditor',
      maintenanceTypesViewer: 'maintenanceTypesViewer',
      periodicityTypesEditor: 'periodicityTypesEditor',
      periodicityTypesViewer: 'periodicityTypesViewer',
      fuelTypesEditor: 'fuelTypesEditor',
      fuelTypesViewer: 'fuelTypesViewer',
      tanksEditor: 'tanksEditor',
      tanksViewer: 'tanksViewer',
      productReceptionEditor: 'productReceptionEditor',
      productReceptionViewer: 'productReceptionViewer',
      productDeviationEditor: 'productDeviationEditor',
      productDeviationViewer: 'productDeviationViewer',
    };
  }

  static labelOf(roleId) {
    if (!this.values[roleId]) {
      return roleId;
    }

    return i18n(`roles.${roleId}.label`);
  }

  static descriptionOf(roleId) {
    if (!this.values[roleId]) {
      return roleId;
    }

    return i18n(`roles.${roleId}.description`);
  }

  static get selectOptions() {
    return _values(this.values).map((value) => ({
      id: value,
      value: value,
      title: this.descriptionOf(value),
      label: this.labelOf(value),
    }));
  }
}

export default Roles;
