import Roles from 'security/roles';
const roles = Roles.values;

class Permissions {
  static get values() {
    return {
      iamEdit: {
        id: 'iamEdit',
        allowedRoles: [
          roles.owner,
          roles.iamSecurityReviewer,
          roles.editor,
        ],
        allowedStorageFolders: ['user'],
      },
      iamCreate: {
        id: 'iamCreate',
        allowedRoles: [
          roles.owner,
          roles.iamSecurityReviewer,
          roles.editor,
        ],
      },
      iamImport: {
        id: 'iamImport',
        allowedRoles: [
          roles.owner,
          roles.iamSecurityReviewer,
          roles.editor,
        ],
      },
      iamRead: {
        id: 'iamRead',
        allowedRoles: [
          roles.owner,
          roles.iamSecurityReviewer,
          roles.editor,
          roles.viewer,
        ],
      },
      iamUserAutocomplete: {
        id: 'iamUserAutocomplete',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,

          roles.personsEditor,
          roles.personsViewer,
        ],
      },
      auditLogRead: {
        id: 'auditLogRead',
        allowedRoles: [roles.owner, roles.auditLogViewer, roles.viewer],
      },
      settingsEdit: {
        id: 'settingsEdit',
        allowedRoles: [roles.owner],
      },
      personsImport: {
        id: 'personsImport',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.personsEditor,
        ],
      },
      personsCreate: {
        id: 'personsCreate',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.personsEditor,
        ],
        allowedStorageFolders: ['persons'],
      },
      personsEdit: {
        id: 'personsEdit',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.personsEditor,
        ],
        allowedStorageFolders: ['persons'],
      },
      personsDestroy: {
        id: 'personsDestroy',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.personsEditor,
        ],
        allowedStorageFolders: ['persons'],
      },
      personsRead: {
        id: 'personsRead',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.personsEditor,
          roles.personsViewer,
        ],
      },
      personsAutocomplete: {
        id: 'personsAutocomplete',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.personsEditor,
          roles.personsViewer,
          roles.stationsEditor,
          roles.stationsViewer,
          roles.workOrdersEditor,
          roles.workOrdersViewer,
        ],
      },

      adminViewer: {
        id: 'adminViewer',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
        ],
        allowedStorageFolders: ['user'],
      },

      stationsImport: {
        id: 'stationsImport',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.stationsEditor,
        ],
      },
      stationsCreate: {
        id: 'stationsCreate',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.stationsEditor,
        ],
        allowedStorageFolders: ['stations'],
      },
      stationsEdit: {
        id: 'stationsEdit',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.stationsEditor,
        ],
        allowedStorageFolders: ['stations'],
      },
      stationsDestroy: {
        id: 'stationsDestroy',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.stationsEditor,
        ],
        allowedStorageFolders: ['stations'],
      },
      stationsRead: {
        id: 'stationsRead',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.stationsEditor,
          roles.stationsViewer,
        ],
      },
      stationsAutocomplete: {
        id: 'stationsAutocomplete',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.stationsEditor,
          roles.stationsViewer,
          roles.personsEditor,
          roles.personsViewer,
          roles.workOrdersEditor,
          roles.workOrdersViewer,
          roles.tanksEditor,
          roles.tanksViewer,
        ],
      },

      addressesImport: {
        id: 'addressesImport',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.addressesEditor,
        ],
      },
      addressesCreate: {
        id: 'addressesCreate',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.addressesEditor,
        ],
        allowedStorageFolders: ['addresses'],
      },
      addressesEdit: {
        id: 'addressesEdit',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.addressesEditor,
        ],
        allowedStorageFolders: ['addresses'],
      },
      addressesDestroy: {
        id: 'addressesDestroy',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.addressesEditor,
        ],
        allowedStorageFolders: ['addresses'],
      },
      addressesRead: {
        id: 'addressesRead',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.addressesEditor,
          roles.addressesViewer,
        ],
      },
      addressesAutocomplete: {
        id: 'addressesAutocomplete',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.addressesEditor,
          roles.addressesViewer,
          roles.stationsEditor,
          roles.stationsViewer,
        ],
      },

      maintenanceTemplatesImport: {
        id: 'maintenanceTemplatesImport',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.maintenanceTemplatesEditor,
        ],
      },
      maintenanceTemplatesCreate: {
        id: 'maintenanceTemplatesCreate',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.maintenanceTemplatesEditor,
        ],
        allowedStorageFolders: ['maintenanceTemplates'],
      },
      maintenanceTemplatesEdit: {
        id: 'maintenanceTemplatesEdit',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.maintenanceTemplatesEditor,
        ],
        allowedStorageFolders: ['maintenanceTemplates'],
      },
      maintenanceTemplatesDestroy: {
        id: 'maintenanceTemplatesDestroy',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.maintenanceTemplatesEditor,
        ],
        allowedStorageFolders: ['maintenanceTemplates'],
      },
      maintenanceTemplatesRead: {
        id: 'maintenanceTemplatesRead',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.maintenanceTemplatesEditor,
          roles.maintenanceTemplatesViewer,
        ],
      },
      maintenanceTemplatesAutocomplete: {
        id: 'maintenanceTemplatesAutocomplete',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.maintenanceTemplatesEditor,
          roles.maintenanceTemplatesViewer,
          roles.stationsEditor,
          roles.stationsViewer,
          roles.taskTemplatesEditor,
          roles.taskTemplatesViewer,
          roles.workOrdersEditor,
          roles.workOrdersViewer,
        ],
      },

      categoryTypesImport: {
        id: 'categoryTypesImport',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.categoryTypesEditor,
        ],
      },
      categoryTypesCreate: {
        id: 'categoryTypesCreate',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.categoryTypesEditor,
        ],
        allowedStorageFolders: ['categoryTypes'],
      },
      categoryTypesEdit: {
        id: 'categoryTypesEdit',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.categoryTypesEditor,
        ],
        allowedStorageFolders: ['categoryTypes'],
      },
      categoryTypesDestroy: {
        id: 'categoryTypesDestroy',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.categoryTypesEditor,
        ],
        allowedStorageFolders: ['categoryTypes'],
      },
      categoryTypesRead: {
        id: 'categoryTypesRead',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.categoryTypesEditor,
          roles.categoryTypesViewer,
        ],
      },
      categoryTypesAutocomplete: {
        id: 'categoryTypesAutocomplete',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.categoryTypesEditor,
          roles.categoryTypesViewer,
          roles.maintenanceTemplatesEditor,
          roles.maintenanceTemplatesViewer,
        ],
      },

      taskTemplatesImport: {
        id: 'taskTemplatesImport',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.taskTemplatesEditor,
        ],
      },
      taskTemplatesCreate: {
        id: 'taskTemplatesCreate',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.taskTemplatesEditor,
        ],
        allowedStorageFolders: ['taskTemplates'],
      },
      taskTemplatesEdit: {
        id: 'taskTemplatesEdit',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.taskTemplatesEditor,
        ],
        allowedStorageFolders: ['taskTemplates'],
      },
      taskTemplatesDestroy: {
        id: 'taskTemplatesDestroy',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.taskTemplatesEditor,
        ],
        allowedStorageFolders: ['taskTemplates'],
      },
      taskTemplatesRead: {
        id: 'taskTemplatesRead',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.taskTemplatesEditor,
          roles.taskTemplatesViewer,
        ],
      },
      taskTemplatesAutocomplete: {
        id: 'taskTemplatesAutocomplete',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.taskTemplatesEditor,
          roles.taskTemplatesViewer,
          roles.maintenanceTemplatesEditor,
          roles.maintenanceTemplatesViewer,
          roles.tasksEditor,
          roles.tasksViewer,
        ],
      },

      workOrdersImport: {
        id: 'workOrdersImport',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.workOrdersEditor,
        ],
      },
      workOrdersCreate: {
        id: 'workOrdersCreate',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.workOrdersEditor,
        ],
        allowedStorageFolders: ['workOrders'],
      },
      workOrdersEdit: {
        id: 'workOrdersEdit',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.workOrdersEditor,
        ],
        allowedStorageFolders: ['workOrders'],
      },
      workOrdersDestroy: {
        id: 'workOrdersDestroy',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.workOrdersEditor,
        ],
        allowedStorageFolders: ['workOrders'],
      },
      workOrdersRead: {
        id: 'workOrdersRead',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.workOrdersEditor,
          roles.workOrdersViewer,
        ],
      },
      workOrdersAutocomplete: {
        id: 'workOrdersAutocomplete',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.workOrdersEditor,
          roles.workOrdersViewer,
          roles.tasksEditor,
          roles.tasksViewer,
        ],
      },

      tasksImport: {
        id: 'tasksImport',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.tasksEditor,
        ],
      },
      tasksCreate: {
        id: 'tasksCreate',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.tasksEditor,
        ],
        allowedStorageFolders: ['tasks'],
      },
      tasksEdit: {
        id: 'tasksEdit',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.tasksEditor,
        ],
        allowedStorageFolders: ['tasks'],
      },
      tasksDestroy: {
        id: 'tasksDestroy',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.tasksEditor,
        ],
        allowedStorageFolders: ['tasks'],
      },
      tasksRead: {
        id: 'tasksRead',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.tasksEditor,
          roles.tasksViewer,
        ],
      },
      tasksAutocomplete: {
        id: 'tasksAutocomplete',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.tasksEditor,
          roles.tasksViewer,
          roles.workOrdersEditor,
          roles.workOrdersViewer,
        ],
      },

      maintenanceTypesImport: {
        id: 'maintenanceTypesImport',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.maintenanceTypesEditor,
        ],
      },
      maintenanceTypesCreate: {
        id: 'maintenanceTypesCreate',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.maintenanceTypesEditor,
        ],
        allowedStorageFolders: ['maintenanceTypes'],
      },
      maintenanceTypesEdit: {
        id: 'maintenanceTypesEdit',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.maintenanceTypesEditor,
        ],
        allowedStorageFolders: ['maintenanceTypes'],
      },
      maintenanceTypesDestroy: {
        id: 'maintenanceTypesDestroy',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.maintenanceTypesEditor,
        ],
        allowedStorageFolders: ['maintenanceTypes'],
      },
      maintenanceTypesRead: {
        id: 'maintenanceTypesRead',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.maintenanceTypesEditor,
          roles.maintenanceTypesViewer,
        ],
      },
      maintenanceTypesAutocomplete: {
        id: 'maintenanceTypesAutocomplete',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.maintenanceTypesEditor,
          roles.maintenanceTypesViewer,
          roles.maintenanceTemplatesEditor,
          roles.maintenanceTemplatesViewer,
        ],
      },

      periodicityTypesImport: {
        id: 'periodicityTypesImport',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.periodicityTypesEditor,
        ],
      },
      periodicityTypesCreate: {
        id: 'periodicityTypesCreate',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.periodicityTypesEditor,
        ],
        allowedStorageFolders: ['periodicityTypes'],
      },
      periodicityTypesEdit: {
        id: 'periodicityTypesEdit',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.periodicityTypesEditor,
        ],
        allowedStorageFolders: ['periodicityTypes'],
      },
      periodicityTypesDestroy: {
        id: 'periodicityTypesDestroy',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.periodicityTypesEditor,
        ],
        allowedStorageFolders: ['periodicityTypes'],
      },
      periodicityTypesRead: {
        id: 'periodicityTypesRead',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.periodicityTypesEditor,
          roles.periodicityTypesViewer,
        ],
      },
      periodicityTypesAutocomplete: {
        id: 'periodicityTypesAutocomplete',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.periodicityTypesEditor,
          roles.periodicityTypesViewer,
          roles.maintenanceTemplatesEditor,
          roles.maintenanceTemplatesViewer,
        ],
      },

      fuelTypesImport: {
        id: 'fuelTypesImport',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.fuelTypesEditor,
        ],
      },
      fuelTypesCreate: {
        id: 'fuelTypesCreate',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.fuelTypesEditor,
        ],
        allowedStorageFolders: ['fuelTypes'],
      },
      fuelTypesEdit: {
        id: 'fuelTypesEdit',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.fuelTypesEditor,
        ],
        allowedStorageFolders: ['fuelTypes'],
      },
      fuelTypesDestroy: {
        id: 'fuelTypesDestroy',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.fuelTypesEditor,
        ],
        allowedStorageFolders: ['fuelTypes'],
      },
      fuelTypesRead: {
        id: 'fuelTypesRead',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.fuelTypesEditor,
          roles.fuelTypesViewer,
        ],
      },
      fuelTypesAutocomplete: {
        id: 'fuelTypesAutocomplete',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.fuelTypesEditor,
          roles.fuelTypesViewer,
          roles.tanksEditor,
          roles.tanksViewer,
        ],
      },

      tanksImport: {
        id: 'tanksImport',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.tanksEditor,
        ],
      },
      tanksCreate: {
        id: 'tanksCreate',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.tanksEditor,
        ],
        allowedStorageFolders: ['tanks'],
      },
      tanksEdit: {
        id: 'tanksEdit',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.tanksEditor,
        ],
        allowedStorageFolders: ['tanks'],
      },
      tanksDestroy: {
        id: 'tanksDestroy',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.tanksEditor,
        ],
        allowedStorageFolders: ['tanks'],
      },
      tanksRead: {
        id: 'tanksRead',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.tanksEditor,
          roles.tanksViewer,
        ],
      },
      tanksAutocomplete: {
        id: 'tanksAutocomplete',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.tanksEditor,
          roles.tanksViewer,
          roles.stationsEditor,
          roles.stationsViewer,
          roles.productReceptionEditor,
          roles.productReceptionViewer,
          roles.productDeviationEditor,
          roles.productDeviationViewer,
        ],
      },

      productReceptionImport: {
        id: 'productReceptionImport',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.productReceptionEditor,
        ],
      },
      productReceptionCreate: {
        id: 'productReceptionCreate',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.productReceptionEditor,
        ],
        allowedStorageFolders: ['productReception'],
      },
      productReceptionEdit: {
        id: 'productReceptionEdit',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.productReceptionEditor,
        ],
        allowedStorageFolders: ['productReception'],
      },
      productReceptionDestroy: {
        id: 'productReceptionDestroy',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.productReceptionEditor,
        ],
        allowedStorageFolders: ['productReception'],
      },
      productReceptionRead: {
        id: 'productReceptionRead',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.productReceptionEditor,
          roles.productReceptionViewer,
        ],
      },
      productReceptionAutocomplete: {
        id: 'productReceptionAutocomplete',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.productReceptionEditor,
          roles.productReceptionViewer,

        ],
      },

      productDeviationImport: {
        id: 'productDeviationImport',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.productDeviationEditor,
        ],
      },
      productDeviationCreate: {
        id: 'productDeviationCreate',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.productDeviationEditor,
        ],
        allowedStorageFolders: ['productDeviation'],
      },
      productDeviationEdit: {
        id: 'productDeviationEdit',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.productDeviationEditor,
        ],
        allowedStorageFolders: ['productDeviation'],
      },
      productDeviationDestroy: {
        id: 'productDeviationDestroy',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.entityEditor,
          roles.productDeviationEditor,
        ],
        allowedStorageFolders: ['productDeviation'],
      },
      productDeviationRead: {
        id: 'productDeviationRead',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.productDeviationEditor,
          roles.productDeviationViewer,
        ],
      },
      productDeviationAutocomplete: {
        id: 'productDeviationAutocomplete',
        allowedRoles: [
          roles.owner,
          roles.editor,
          roles.viewer,
          roles.entityEditor,
          roles.productDeviationEditor,
          roles.productDeviationViewer,

        ],
      },
    };
  }

  static get asArray() {
    return Object.keys(this.values).map((value) => {
      return this.values[value];
    });
  }
}

export default Permissions;
