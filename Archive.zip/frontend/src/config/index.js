const config = require(`./${
  process.env.REACT_APP_ENVIRONMENT
}`).default;

export default config;
