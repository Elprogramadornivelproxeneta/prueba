const firebaseConfig = {
  apiKey: "AIzaSyBcRbOyB-oVihESu0OE0njSr4lufwJQz8Y",
  authDomain: "gasmate-f6761.firebaseapp.com",
  databaseURL: "https://gasmate-f6761.firebaseio.com",
  projectId: "gasmate-f6761",
  storageBucket: "gasmate-f6761.appspot.com",
  messagingSenderId: "218595414129",
  appId: "1:218595414129:web:17a842cf52d3ef69e08bd0",
  measurementId: "G-PXLQKPPPCY"
};

// Cloud Functions
const backendUrl = `https://us-central1-${
  firebaseConfig.projectId
}.cloudfunctions.net/api/api`;

// App Engine
// const backendUrl = `<insert app engine url here>`;

export default {
  firebaseConfig,
  backendUrl,
};
