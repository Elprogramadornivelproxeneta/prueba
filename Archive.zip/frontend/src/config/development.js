const firebaseConfig = {
  apiKey: "AIzaSyArpcf5A_IKYUO0QocxwGU23Fw1rhDT9ac",
  authDomain: "gasmatedev.firebaseapp.com",
  databaseURL: "https://gasmatedev.firebaseio.com",
  projectId: "gasmatedev",
  storageBucket: "gasmatedev.appspot.com",
  messagingSenderId: "669256237438",
  appId: "1:669256237438:web:3fe16046dc45ad40b5f32f"
};

// Cloud Functions
const backendUrl = `https://us-central1-${
  firebaseConfig.projectId
}.cloudfunctions.net/api/api`;

// App Engine
// const backendUrl = `<insert app engine url here>`;

export default {
  firebaseConfig,
  backendUrl,
};
