const firebaseConfig = null;
const backendUrl = null;

export default {
  firebaseConfig,
  backendUrl,
};
