const ptBR = {
  common: {
    or: 'ou',
    cancel: 'Cancelar',
    reset: 'Limpar',
    save: 'Salvar',
    search: 'Buscar',
    edit: 'Editar',
    remove: 'Remover',
    new: 'Novo',
    export: 'Exportar para Excel',
    noDataToExport: 'Não há dados para exportar',
    import: 'Importar',
    discard: 'Descartar',
    yes: 'Sim',
    no: 'Não',
    pause: 'Pausar',
    areYouSure: 'Tem certeza?',
    view: 'Visualizar',
    destroy: 'Deletar',
    mustSelectARow: 'Selecine uma linha',
    start: 'Inicio',
    end: 'Fim',
  },

  app: {
    title: 'Aplicação',
  },

  entities: {
    persons: {
      name: 'Persons',
      label: 'Persons',
      menu: 'Persons',
      exporterFileName: 'Persons_exportados',
      list: {
        menu: 'Persons',
        title: 'Persons',
      },
      create: {
        success: 'Persons salvo com sucesso',
      },
      update: {
        success: 'Persons salvo com sucesso',
      },
      destroy: {
        success: 'Persons deletado com sucesso',
      },
      destroyAll: {
        success: 'Persons(s) deletado com sucesso',
      },
      edit: {
        title: 'Editar Persons',
      },
      fields: {
        id: 'Id',
        'userId': 'UserId',
        'name': 'Name',
        'paternalSurname': 'PaternalSurname',
        'maternalSurname': 'MaternalSurname',
        'gender': 'Gender',
        'birthdateRange': 'Birthdate',
        'birthdate': 'Birthdate',
        'rfc': 'RFC',
        'curp': 'CURP',
        'identityDocument': 'IdentityDocument',
        'identityDocumentType': 'IdentityDocumentType',
        'stations': 'Stations',
        createdAt: 'Criado em',
        updatedAt: 'Atualizado em',
        createdAtRange: 'Criado em',
      },
      enumerators: {
        'gender': {
          'male': 'Male',
          'female': 'Female',
        },
        'identityDocumentType': {
          'INE': 'INE',
          'Pasaporte': 'Pasaporte',
          'Licencia': 'Licencia',
        },
      },
      new: {
        title: 'Novo Persons',
      },
      view: {
        title: 'Visualizar Persons',
      },
      importer: {
        title: 'Importar Persons',
        fileName: 'persons_template_importacao',
        hint:
          'Arquivos/Imagens devem ser as URLs dos arquivos, separados por espaço. Relacionamentos devem ser os IDs separados por espaço.',
      },
    },

    stations: {
      name: 'Stations',
      label: 'Stations',
      menu: 'Stations',
      exporterFileName: 'Stations_exportados',
      list: {
        menu: 'Stations',
        title: 'Stations',
      },
      create: {
        success: 'Stations salvo com sucesso',
      },
      update: {
        success: 'Stations salvo com sucesso',
      },
      destroy: {
        success: 'Stations deletado com sucesso',
      },
      destroyAll: {
        success: 'Stations(s) deletado com sucesso',
      },
      edit: {
        title: 'Editar Stations',
      },
      fields: {
        id: 'Id',
        'identifier': 'Identifier',
        'name': 'Name',
        'address': 'Address',
        'legalRepresentative': 'LegalRepresentative',
        'users': 'Users',
        'maintenanceTemplates': 'MaintenanceTemplates',
        'tanks': 'Tanks',
        createdAt: 'Criado em',
        updatedAt: 'Atualizado em',
        createdAtRange: 'Criado em',
      },
      enumerators: {

      },
      new: {
        title: 'Novo Stations',
      },
      view: {
        title: 'Visualizar Stations',
      },
      importer: {
        title: 'Importar Stations',
        fileName: 'stations_template_importacao',
        hint:
          'Arquivos/Imagens devem ser as URLs dos arquivos, separados por espaço. Relacionamentos devem ser os IDs separados por espaço.',
      },
    },

    addresses: {
      name: 'Addresses',
      label: 'Addresses',
      menu: 'Addresses',
      exporterFileName: 'Addresses_exportados',
      list: {
        menu: 'Addresses',
        title: 'Addresses',
      },
      create: {
        success: 'Addresses salvo com sucesso',
      },
      update: {
        success: 'Addresses salvo com sucesso',
      },
      destroy: {
        success: 'Addresses deletado com sucesso',
      },
      destroyAll: {
        success: 'Addresses(s) deletado com sucesso',
      },
      edit: {
        title: 'Editar Addresses',
      },
      fields: {
        id: 'Id',
        'addressLine1': 'AddressLine1',
        'addressLine2': 'AddressLine2',
        'postalCode': 'PostalCode',
        'colony': 'Colony',
        'municipality': 'Municipality',
        'state': 'State',
        createdAt: 'Criado em',
        updatedAt: 'Atualizado em',
        createdAtRange: 'Criado em',
      },
      enumerators: {
        'state': {
          'AGS': 'AGS',
          'CDMX': 'CDMX',
        },
      },
      new: {
        title: 'Novo Addresses',
      },
      view: {
        title: 'Visualizar Addresses',
      },
      importer: {
        title: 'Importar Addresses',
        fileName: 'addresses_template_importacao',
        hint:
          'Arquivos/Imagens devem ser as URLs dos arquivos, separados por espaço. Relacionamentos devem ser os IDs separados por espaço.',
      },
    },

    maintenanceTemplates: {
      name: 'MaintenanceTemplates',
      label: 'MaintenanceTemplates',
      menu: 'MaintenanceTemplates',
      exporterFileName: 'MaintenanceTemplates_exportados',
      list: {
        menu: 'MaintenanceTemplates',
        title: 'MaintenanceTemplates',
      },
      create: {
        success: 'MaintenanceTemplates salvo com sucesso',
      },
      update: {
        success: 'MaintenanceTemplates salvo com sucesso',
      },
      destroy: {
        success: 'MaintenanceTemplates deletado com sucesso',
      },
      destroyAll: {
        success: 'MaintenanceTemplates(s) deletado com sucesso',
      },
      edit: {
        title: 'Editar MaintenanceTemplates',
      },
      fields: {
        id: 'Id',
        'identifier': 'Identifier',
        'name': 'Name',
        'description': 'Description',
        'maintenanceType': 'MaintenanceType',
        'priority': 'Priority',
        'versionRange': 'Version',
        'version': 'Version',
        'category': 'Category',
        'periodicity': 'Periodicity',
        'duration': 'Duration',
        'isEvidenceRequired': 'IsEvidenceRequired',
        'isSignatureRequired': 'IsSignatureRequired',
        'tasks': 'Tasks',
        'relatedMaintenances': 'RelatedMaintenances',
        createdAt: 'Criado em',
        updatedAt: 'Atualizado em',
        createdAtRange: 'Criado em',
      },
      enumerators: {
        'priority': {
          'Alta': 'Alta',
          'Media': 'Media',
          'Baja': 'Baja',
        },
      },
      new: {
        title: 'Novo MaintenanceTemplates',
      },
      view: {
        title: 'Visualizar MaintenanceTemplates',
      },
      importer: {
        title: 'Importar MaintenanceTemplates',
        fileName: 'maintenanceTemplates_template_importacao',
        hint:
          'Arquivos/Imagens devem ser as URLs dos arquivos, separados por espaço. Relacionamentos devem ser os IDs separados por espaço.',
      },
    },

    categoryTypes: {
      name: 'CategoryTypes',
      label: 'CategoryTypes',
      menu: 'CategoryTypes',
      exporterFileName: 'CategoryTypes_exportados',
      list: {
        menu: 'CategoryTypes',
        title: 'CategoryTypes',
      },
      create: {
        success: 'CategoryTypes salvo com sucesso',
      },
      update: {
        success: 'CategoryTypes salvo com sucesso',
      },
      destroy: {
        success: 'CategoryTypes deletado com sucesso',
      },
      destroyAll: {
        success: 'CategoryTypes(s) deletado com sucesso',
      },
      edit: {
        title: 'Editar CategoryTypes',
      },
      fields: {
        id: 'Id',
        'name': 'Name',
        'description': 'Description',
        'orderRange': 'Order',
        'order': 'Order',
        createdAt: 'Criado em',
        updatedAt: 'Atualizado em',
        createdAtRange: 'Criado em',
      },
      enumerators: {

      },
      new: {
        title: 'Novo CategoryTypes',
      },
      view: {
        title: 'Visualizar CategoryTypes',
      },
      importer: {
        title: 'Importar CategoryTypes',
        fileName: 'categoryTypes_template_importacao',
        hint:
          'Arquivos/Imagens devem ser as URLs dos arquivos, separados por espaço. Relacionamentos devem ser os IDs separados por espaço.',
      },
    },

    taskTemplates: {
      name: 'TaskTemplates',
      label: 'TaskTemplates',
      menu: 'TaskTemplates',
      exporterFileName: 'TaskTemplates_exportados',
      list: {
        menu: 'TaskTemplates',
        title: 'TaskTemplates',
      },
      create: {
        success: 'TaskTemplates salvo com sucesso',
      },
      update: {
        success: 'TaskTemplates salvo com sucesso',
      },
      destroy: {
        success: 'TaskTemplates deletado com sucesso',
      },
      destroyAll: {
        success: 'TaskTemplates(s) deletado com sucesso',
      },
      edit: {
        title: 'Editar TaskTemplates',
      },
      fields: {
        id: 'Id',
        'orderRange': 'Order',
        'order': 'Order',
        'name': 'Name',
        'description': 'Description',
        'isEvidenceRequired': 'IsEvidenceRequired',
        'maintenanceTemplateId': 'MaintenanceTemplateId',
        createdAt: 'Criado em',
        updatedAt: 'Atualizado em',
        createdAtRange: 'Criado em',
      },
      enumerators: {

      },
      new: {
        title: 'Novo TaskTemplates',
      },
      view: {
        title: 'Visualizar TaskTemplates',
      },
      importer: {
        title: 'Importar TaskTemplates',
        fileName: 'taskTemplates_template_importacao',
        hint:
          'Arquivos/Imagens devem ser as URLs dos arquivos, separados por espaço. Relacionamentos devem ser os IDs separados por espaço.',
      },
    },

    workOrders: {
      name: 'Work Orders',
      label: 'WorkOrders',
      menu: 'WorkOrders',
      exporterFileName: 'Work Orders_exportados',
      list: {
        menu: 'WorkOrders',
        title: 'WorkOrders',
      },
      create: {
        success: 'Work Orders salvo com sucesso',
      },
      update: {
        success: 'Work Orders salvo com sucesso',
      },
      destroy: {
        success: 'Work Orders deletado com sucesso',
      },
      destroyAll: {
        success: 'Work Orders(s) deletado com sucesso',
      },
      edit: {
        title: 'Editar Work Orders',
      },
      fields: {
        id: 'Id',
        'station': 'Station',
        'maintenanceTemplate': 'MaintenanceTemplate',
        'title': 'Title',
        'status': 'Status',
        'plannedStartOnRange': 'PlannedStartOn',
        'plannedStartOn': 'PlannedStartOn',
        'actualStartOnRange': 'ActualStartOn',
        'actualStartOn': 'ActualStartOn',
        'finishedOnRange': 'FinishedOn',
        'finishedOn': 'FinishedOn',
        'durationRange': 'Duration',
        'duration': 'Duration',
        'operator': 'Operator',
        'tasks': 'Tasks',
        'files': 'Files',
        'signature': 'Signature',
        'evidences': 'Evidences',
        createdAt: 'Criado em',
        updatedAt: 'Atualizado em',
        createdAtRange: 'Criado em',
      },
      enumerators: {
        'status': {
          'PENDING': 'PENDING',
          'ASSIGNED': 'ASSIGNED',
          'IN_PROGRESS': 'IN_PROGRESS',
          'DONE': 'DONE',
        },
      },
      new: {
        title: 'Novo Work Orders',
      },
      view: {
        title: 'Visualizar Work Orders',
      },
      importer: {
        title: 'Importar WorkOrders',
        fileName: 'workOrders_template_importacao',
        hint:
          'Arquivos/Imagens devem ser as URLs dos arquivos, separados por espaço. Relacionamentos devem ser os IDs separados por espaço.',
      },
    },

    tasks: {
      name: 'Tasks',
      label: 'Tasks',
      menu: 'Tasks',
      exporterFileName: 'Tasks_exportados',
      list: {
        menu: 'Tasks',
        title: 'Tasks',
      },
      create: {
        success: 'Tasks salvo com sucesso',
      },
      update: {
        success: 'Tasks salvo com sucesso',
      },
      destroy: {
        success: 'Tasks deletado com sucesso',
      },
      destroyAll: {
        success: 'Tasks(s) deletado com sucesso',
      },
      edit: {
        title: 'Editar Tasks',
      },
      fields: {
        id: 'Id',
        'result': 'Result',
        'evidences': 'Evidences',
        'workOrderId': 'WorkOrderId',
        'taskTemplateId': 'TaskTemplateId',
        'name': 'Name',
        createdAt: 'Criado em',
        updatedAt: 'Atualizado em',
        createdAtRange: 'Criado em',
      },
      enumerators: {
        'result': {
          'VALID': 'VALID',
          'INVALID': 'INVALID',
        },
      },
      new: {
        title: 'Novo Tasks',
      },
      view: {
        title: 'Visualizar Tasks',
      },
      importer: {
        title: 'Importar Tasks',
        fileName: 'tasks_template_importacao',
        hint:
          'Arquivos/Imagens devem ser as URLs dos arquivos, separados por espaço. Relacionamentos devem ser os IDs separados por espaço.',
      },
    },

    maintenanceTypes: {
      name: 'MaintenanceTypes',
      label: 'MaintenanceTypes',
      menu: 'MaintenanceTypes',
      exporterFileName: 'MaintenanceTypes_exportados',
      list: {
        menu: 'MaintenanceTypes',
        title: 'MaintenanceTypes',
      },
      create: {
        success: 'MaintenanceTypes salvo com sucesso',
      },
      update: {
        success: 'MaintenanceTypes salvo com sucesso',
      },
      destroy: {
        success: 'MaintenanceTypes deletado com sucesso',
      },
      destroyAll: {
        success: 'MaintenanceTypes(s) deletado com sucesso',
      },
      edit: {
        title: 'Editar MaintenanceTypes',
      },
      fields: {
        id: 'Id',
        'orderRange': 'Order',
        'order': 'Order',
        'name': 'Name',
        'description': 'Description',
        createdAt: 'Criado em',
        updatedAt: 'Atualizado em',
        createdAtRange: 'Criado em',
      },
      enumerators: {

      },
      new: {
        title: 'Novo MaintenanceTypes',
      },
      view: {
        title: 'Visualizar MaintenanceTypes',
      },
      importer: {
        title: 'Importar MaintenanceTypes',
        fileName: 'maintenanceTypes_template_importacao',
        hint:
          'Arquivos/Imagens devem ser as URLs dos arquivos, separados por espaço. Relacionamentos devem ser os IDs separados por espaço.',
      },
    },

    periodicityTypes: {
      name: 'PeriodicityTypes',
      label: 'PeriodicityTypes',
      menu: 'PeriodicityTypes',
      exporterFileName: 'PeriodicityTypes_exportados',
      list: {
        menu: 'PeriodicityTypes',
        title: 'PeriodicityTypes',
      },
      create: {
        success: 'PeriodicityTypes salvo com sucesso',
      },
      update: {
        success: 'PeriodicityTypes salvo com sucesso',
      },
      destroy: {
        success: 'PeriodicityTypes deletado com sucesso',
      },
      destroyAll: {
        success: 'PeriodicityTypes(s) deletado com sucesso',
      },
      edit: {
        title: 'Editar PeriodicityTypes',
      },
      fields: {
        id: 'Id',
        'orderRange': 'Order',
        'order': 'Order',
        'name': 'Name',
        'incrementRange': 'Increment',
        'increment': 'Increment',
        'unit': 'Unit',
        createdAt: 'Criado em',
        updatedAt: 'Atualizado em',
        createdAtRange: 'Criado em',
      },
      enumerators: {

      },
      new: {
        title: 'Novo PeriodicityTypes',
      },
      view: {
        title: 'Visualizar PeriodicityTypes',
      },
      importer: {
        title: 'Importar PeriodicityTypes',
        fileName: 'periodicityTypes_template_importacao',
        hint:
          'Arquivos/Imagens devem ser as URLs dos arquivos, separados por espaço. Relacionamentos devem ser os IDs separados por espaço.',
      },
    },

    fuelTypes: {
      name: 'FuelTypes',
      label: 'FuelTypes',
      menu: 'FuelTypes',
      exporterFileName: 'FuelTypes_exportados',
      list: {
        menu: 'FuelTypes',
        title: 'FuelTypes',
      },
      create: {
        success: 'FuelTypes salvo com sucesso',
      },
      update: {
        success: 'FuelTypes salvo com sucesso',
      },
      destroy: {
        success: 'FuelTypes deletado com sucesso',
      },
      destroyAll: {
        success: 'FuelTypes(s) deletado com sucesso',
      },
      edit: {
        title: 'Editar FuelTypes',
      },
      fields: {
        id: 'Id',
        'name': 'Name',
        'description': 'Description',
        createdAt: 'Criado em',
        updatedAt: 'Atualizado em',
        createdAtRange: 'Criado em',
      },
      enumerators: {

      },
      new: {
        title: 'Novo FuelTypes',
      },
      view: {
        title: 'Visualizar FuelTypes',
      },
      importer: {
        title: 'Importar FuelTypes',
        fileName: 'fuelTypes_template_importacao',
        hint:
          'Arquivos/Imagens devem ser as URLs dos arquivos, separados por espaço. Relacionamentos devem ser os IDs separados por espaço.',
      },
    },

    tanks: {
      name: 'Tanks',
      label: 'Tanks',
      menu: 'Tanks',
      exporterFileName: 'Tanks_exportados',
      list: {
        menu: 'Tanks',
        title: 'Tanks',
      },
      create: {
        success: 'Tanks salvo com sucesso',
      },
      update: {
        success: 'Tanks salvo com sucesso',
      },
      destroy: {
        success: 'Tanks deletado com sucesso',
      },
      destroyAll: {
        success: 'Tanks(s) deletado com sucesso',
      },
      edit: {
        title: 'Editar Tanks',
      },
      fields: {
        id: 'Id',
        'tankNumberRange': 'TankNumber',
        'tankNumber': 'TankNumber',
        'fuelType': 'FuelType',
        'volumeRange': 'Volume',
        'volume': 'Volume',
        'station': 'Station',
        createdAt: 'Criado em',
        updatedAt: 'Atualizado em',
        createdAtRange: 'Criado em',
      },
      enumerators: {

      },
      new: {
        title: 'Novo Tanks',
      },
      view: {
        title: 'Visualizar Tanks',
      },
      importer: {
        title: 'Importar Tanks',
        fileName: 'tanks_template_importacao',
        hint:
          'Arquivos/Imagens devem ser as URLs dos arquivos, separados por espaço. Relacionamentos devem ser os IDs separados por espaço.',
      },
    },

    productReception: {
      name: 'ProductReception',
      label: 'ProductReceptions',
      menu: 'ProductReceptions',
      exporterFileName: 'ProductReception_exportados',
      list: {
        menu: 'ProductReceptions',
        title: 'ProductReceptions',
      },
      create: {
        success: 'ProductReception salvo com sucesso',
      },
      update: {
        success: 'ProductReception salvo com sucesso',
      },
      destroy: {
        success: 'ProductReception deletado com sucesso',
      },
      destroyAll: {
        success: 'ProductReception(s) deletado com sucesso',
      },
      edit: {
        title: 'Editar ProductReception',
      },
      fields: {
        id: 'Id',
        'referral': 'Referral',
        'tank': 'Tank',
        'quantityRange': 'Quantity',
        'quantity': 'Quantity',
        'startTimeRange': 'StartTime',
        'startTime': 'StartTime',
        'endTimeRange': 'EndTime',
        'endTime': 'EndTime',
        createdAt: 'Criado em',
        updatedAt: 'Atualizado em',
        createdAtRange: 'Criado em',
      },
      enumerators: {

      },
      new: {
        title: 'Novo ProductReception',
      },
      view: {
        title: 'Visualizar ProductReception',
      },
      importer: {
        title: 'Importar ProductReceptions',
        fileName: 'productReception_template_importacao',
        hint:
          'Arquivos/Imagens devem ser as URLs dos arquivos, separados por espaço. Relacionamentos devem ser os IDs separados por espaço.',
      },
    },

    productDeviation: {
      name: 'ProductDeviation',
      label: 'ProductDeviations',
      menu: 'ProductDeviations',
      exporterFileName: 'ProductDeviation_exportados',
      list: {
        menu: 'ProductDeviations',
        title: 'ProductDeviations',
      },
      create: {
        success: 'ProductDeviation salvo com sucesso',
      },
      update: {
        success: 'ProductDeviation salvo com sucesso',
      },
      destroy: {
        success: 'ProductDeviation deletado com sucesso',
      },
      destroyAll: {
        success: 'ProductDeviation(s) deletado com sucesso',
      },
      edit: {
        title: 'Editar ProductDeviation',
      },
      fields: {
        id: 'Id',
        'tank': 'Tank',
        'initialInventoryVedeerRange': 'InitialInventoryVedeer',
        'initialInventoryVedeer': 'InitialInventoryVedeer',
        'finalInventoryVedeerRange': 'FinalInventoryVedeer',
        'finalInventoryVedeer': 'FinalInventoryVedeer',
        'volumePurchasedRange': 'VolumePurchased',
        'volumePurchased': 'VolumePurchased',
        'volumeSoldRange': 'VolumeSold',
        'volumeSold': 'VolumeSold',
        'finalPhysicalInventoryRange': 'FinalPhysicalInventory',
        'finalPhysicalInventory': 'FinalPhysicalInventory',
        'differenceRange': 'Difference',
        'difference': 'Difference',
        createdAt: 'Criado em',
        updatedAt: 'Atualizado em',
        createdAtRange: 'Criado em',
      },
      enumerators: {

      },
      new: {
        title: 'Novo ProductDeviation',
      },
      view: {
        title: 'Visualizar ProductDeviation',
      },
      importer: {
        title: 'Importar ProductDeviations',
        fileName: 'productDeviation_template_importacao',
        hint:
          'Arquivos/Imagens devem ser as URLs dos arquivos, separados por espaço. Relacionamentos devem ser os IDs separados por espaço.',
      },
    },
  },

  auth: {
    profile: {
      title: 'Editar Perfil',
      success: 'Perfil atualizado com sucesso',
    },
    createAnAccount: 'Criar uma conta',
    rememberMe: 'Lembrar-me',
    forgotPassword: 'Esqueci minha senha',
    signin: 'Entrar',
    signup: 'Registrar',
    signout: 'Sair',
    alreadyHaveAnAccount: 'Já possui uma conta? Entre.',
    signinWithAnotherAccount: 'Entrar com outra conta',
    emailUnverified: {
      message: `Por favor, confirme seu email em <strong>{0}</strong> para continuar.`,
      submit: `Reenviar confirmação por email`,
    },
    emptyPermissions: {
      message: `Você ainda não possui permissões. Aguarde o administrador conceder seus privilégios.`,
    },
    passwordResetEmail: {
      message: 'Enviar email de redefinição de senha',
      error: `Email não encontrado`,
    },
    passwordReset: {
      message: 'Alterar senha',
    },
    emailAddressVerificationEmail: {
      error: `Email não encontrado`,
    },
    verificationEmailSuccess: `Verificação de email enviada com sucesso`,
    passwordResetEmailSuccess: `Email de redefinição de senha enviado com sucesso`,
    passwordResetSuccess: `Senha alterada com sucesso`,
    verifyEmail: {
      success: 'Email verificado com sucesso',
      message:
        'Aguarde um momento, seu email está sendo verificado...',
    },
  },

  roles: {
    owner: {
      label: 'Proprietário',
      description: 'Acesso completo a todos os recursos',
    },
    editor: {
      label: 'Editor',
      description: 'Acesso para edição a todos os recursos',
    },
    viewer: {
      label: 'Visualizador',
      description:
        'Acesso de visualização a todos os recursos',
    },
    auditLogViewer: {
      label: 'Visualizador de Registros de Autoria',
      description:
        'Acesso de visualização dos registros de autoria',
    },
    iamSecurityReviewer: {
      label: 'Revisor de segurança',
      description: `Acesso total para gerenciar as funções do usuário`,
    },
    entityEditor: {
      label: 'Editor de Entidades',
      description: 'Acesso de edição a todas as entidades',
    },
    entityViewer: {
      label: 'Visualizador de Entidades',
      description:
        'Acesso de visualização a todas as entidades',
    },
    personsEditor: {
      label: 'Editor de Persons',
      description: 'Acesso de edição aos Persons',
    },
    personsViewer: {
      label: 'Visualizador de Persons',
      description: 'Acesso de visualização aos Persons',
    },
    stationsEditor: {
      label: 'Editor de Stations',
      description: 'Acesso de edição aos Stations',
    },
    stationsViewer: {
      label: 'Visualizador de Stations',
      description: 'Acesso de visualização aos Stations',
    },
    addressesEditor: {
      label: 'Editor de Addresses',
      description: 'Acesso de edição aos Addresses',
    },
    addressesViewer: {
      label: 'Visualizador de Addresses',
      description: 'Acesso de visualização aos Addresses',
    },
    maintenanceTemplatesEditor: {
      label: 'Editor de MaintenanceTemplates',
      description: 'Acesso de edição aos MaintenanceTemplates',
    },
    maintenanceTemplatesViewer: {
      label: 'Visualizador de MaintenanceTemplates',
      description: 'Acesso de visualização aos MaintenanceTemplates',
    },
    categoryTypesEditor: {
      label: 'Editor de CategoryTypes',
      description: 'Acesso de edição aos CategoryTypes',
    },
    categoryTypesViewer: {
      label: 'Visualizador de CategoryTypes',
      description: 'Acesso de visualização aos CategoryTypes',
    },
    taskTemplatesEditor: {
      label: 'Editor de TaskTemplates',
      description: 'Acesso de edição aos TaskTemplates',
    },
    taskTemplatesViewer: {
      label: 'Visualizador de TaskTemplates',
      description: 'Acesso de visualização aos TaskTemplates',
    },
    workOrdersEditor: {
      label: 'Editor de WorkOrders',
      description: 'Acesso de edição aos WorkOrders',
    },
    workOrdersViewer: {
      label: 'Visualizador de WorkOrders',
      description: 'Acesso de visualização aos WorkOrders',
    },
    tasksEditor: {
      label: 'Editor de Tasks',
      description: 'Acesso de edição aos Tasks',
    },
    tasksViewer: {
      label: 'Visualizador de Tasks',
      description: 'Acesso de visualização aos Tasks',
    },
    maintenanceTypesEditor: {
      label: 'Editor de MaintenanceTypes',
      description: 'Acesso de edição aos MaintenanceTypes',
    },
    maintenanceTypesViewer: {
      label: 'Visualizador de MaintenanceTypes',
      description: 'Acesso de visualização aos MaintenanceTypes',
    },
    periodicityTypesEditor: {
      label: 'Editor de PeriodicityTypes',
      description: 'Acesso de edição aos PeriodicityTypes',
    },
    periodicityTypesViewer: {
      label: 'Visualizador de PeriodicityTypes',
      description: 'Acesso de visualização aos PeriodicityTypes',
    },
    fuelTypesEditor: {
      label: 'Editor de FuelTypes',
      description: 'Acesso de edição aos FuelTypes',
    },
    fuelTypesViewer: {
      label: 'Visualizador de FuelTypes',
      description: 'Acesso de visualização aos FuelTypes',
    },
    tanksEditor: {
      label: 'Editor de Tanks',
      description: 'Acesso de edição aos Tanks',
    },
    tanksViewer: {
      label: 'Visualizador de Tanks',
      description: 'Acesso de visualização aos Tanks',
    },
    productReceptionEditor: {
      label: 'Editor de ProductReceptions',
      description: 'Acesso de edição aos ProductReceptions',
    },
    productReceptionViewer: {
      label: 'Visualizador de ProductReceptions',
      description: 'Acesso de visualização aos ProductReceptions',
    },
    productDeviationEditor: {
      label: 'Editor de ProductDeviations',
      description: 'Acesso de edição aos ProductDeviations',
    },
    productDeviationViewer: {
      label: 'Visualizador de ProductDeviations',
      description: 'Acesso de visualização aos ProductDeviations',
    },
  },

  iam: {
    title: 'Gerenciamento de usuários e permissões',
    menu: 'IAM',
    disable: 'Desabilitar',
    disabled: 'Desabilitado',
    enabled: 'Habilitado',
    enable: 'Habilitar',
    doEnableSuccess: 'Usuário habilitado com sucesso',
    doDisableSuccess: 'Usuário desabilitado com sucesso',
    doDisableAllSuccess:
      'Usuário(s) desabilitado(s) com sucesso',
    doEnableAllSuccess:
      'Usuário(s) habilidatos com sucesso',
    doAddSuccess: 'Usuário(s) salvos com sucesso',
    doUpdateSuccess: 'Usuário salvo com sucesso',
    viewBy: 'Visualizar por',
    users: {
      name: 'users',
      label: 'Usuários',
      exporterFileName: 'usuarios_exportados',
      doRemoveAllSelectedSuccess:
        'Permissões removidas com sucesso',
    },
    roles: {
      label: 'Perfis',
      doRemoveAllSelectedSuccess:
        'Permissões removidas com sucesso',
    },
    edit: {
      title: 'Editar usuário',
    },
    new: {
      title: 'Novo(s) Usuário(s)',
      titleModal: 'Novo Usuário',
      emailsHint:
        'Separe múltiplos endereços de e-mail usando a vírgula.',
    },
    view: {
      title: 'Visualizar Usuário',
      activity: 'Atividades',
    },
    importer: {
      title: 'Importar Usuários',
      fileName: 'usuarios_template_importacao',
      hint:
      'Arquivos/Imagens devem ser as URLs dos arquivos, separados por espaço.<br/> Relacionamentos devem ser os IDs separados por espaço.',
    },
    errors: {
      userAlreadyExists: 'Usuário com este email já existe',
      userNotFound: 'Usuário não encontrado',
      disablingHimself: `Você não pode desativar-se`,
      revokingOwnPermission: `Você não pode revogar sua própria permissão de proprietário`,
    },
  },

  user: {
    fields: {
      id: 'Id',
      authenticationUid: 'Id de autenticação',
      avatars: 'Avatar',
      email: 'Email',
      emails: 'Email(s)',
      fullName: 'Nome',
      firstName: 'Nome',
      lastName: 'Sobrenome',
      status: 'Estado',
      disabled: 'Desativado',
      phoneNumber: 'Telefone',
      role: 'Perfil',
      createdAt: 'Criado em',
      updatedAt: 'Atualizado em',
      roleUser: 'Perfil/Usuário',
      roles: 'Perfis',
      createdAtRange: 'Criado em',
      password: 'Senha',
      rememberMe: 'Lembrar-me',
    },
    enabled: 'Habilitado',
    disabled: 'Desabilitado',
    validations: {
      // eslint-disable-next-line
      email: 'Email ${value} é inválido',
    },
  },

  auditLog: {
    menu: 'Registros de Auditoria',
    title: 'Registros de Auditoria',
    exporterFileName: 'registros_autoria_exportados',
    entityNamesHint:
      'Separe múltiplas entidades por vírgula',
    fields: {
      id: 'Id',
      timestampRange: 'Período',
      entityName: 'Entidade',
      entityNames: 'Entidades',
      entityId: 'ID da Entidade',
      action: 'Ação',
      values: 'Valores',
      timestamp: 'Data',
      createdByEmail: 'Email do Usuário',
    },
  },
  settings: {
    title: 'Configurações',
    menu: 'Configurações',
    save: {
      success:
        'Configurações salvas com sucesso. A página irá recarregar em {0} para que as alterações tenham efeito.',
    },
    fields: {
      primary: 'Cor Primária',
      secondary: 'Cor Secundária',
      shade: 'Tom',
    },
  },
  home: {
    menu: 'Inicial',
    message: `Esta página usa dados falsos apenas para fins de demonstração. Você pode editá-la em frontend/view/home/HomePage.js.`,
    charts: {
      day: 'Dia',
      red: 'Vermelho',
      green: 'Verde',
      yellow: 'Amarelho',
      grey: 'Cinza',
      blue: 'Azul',
      orange: 'Laranja',
      months: {
        1: 'Janeiro',
        2: 'Fevereiro',
        3: 'Março',
        4: 'Abril',
        5: 'Maio',
        6: 'Junho',
        7: 'Julho',
      },
      eating: 'Comendo',
      drinking: 'Bebendo',
      sleeping: 'Dormindo',
      designing: 'Projetando',
      coding: 'Codificando',
      cycling: 'Pedalando',
      running: 'Correndo',
      customer: 'Cliente',
    },
  },
  errors: {
    backToHome: 'Voltar a página inicial',
    403: `Desculpe, você não tem acesso a esta página`,
    404: 'Desculpe, a página que você visitou não existe',
    500: 'Desculpe, o servidor está relatando um erro',
    forbidden: {
      message: 'Acesso negado',
    },
    validation: {
      message: 'Ocorreu um erro',
    },
    defaultErrorMessage: 'Ops, ocorreu um erro',
  },
  // See https://github.com/jquense/yup#using-a-custom-locale-dictionary
  /* eslint-disable */
  validation: {
    mixed: {
      default: '${path} é inválido',
      required: '${path} é obrigatório',
      oneOf:
        '${path} deve ser um dos seguintes valores: ${values}',
      notOneOf:
        '${path} não deve ser um dos seguintes valores: ${values}',
      notType: ({ path, type, value, originalValue }) => {
        return `${path} deve ser um ${type}`;
      },
    },
    string: {
      length: '${path} deve possuir ${length} caracteres',
      min:
        '${path} deve possuir ao menos ${min} caracteres',
      max:
        '${path} deve possui no máximo ${max} caracteres',
      matches:
        '${path} deve respeitar o padrão: "${regex}"',
      email: '${path} deve ser um email válido',
      url: '${path} deve ser uma URL válida',
      trim:
        '${path} deve ser uma palavra sem espaços em branco',
      lowercase: '${path} deve ser minúsculo',
      uppercase: '${path} deve ser maiúsculo',
      selected: '${path} deve ser selecionado',
    },
    number: {
      min: '${path} deve ser maior ou igual a ${min}',
      max: '${path} deve ser menor ou igual a ${max}',
      lessThan: '${path} deve ser menor que ${less}',
      moreThan: '${path} deve ser maior que ${more}',
      notEqual: '${path} não deve ser igual a ${notEqual}',
      positive: '${path} deve ser um número positivo',
      negative: '${path} deve ser um número negativo',
      integer: '${path} deve ser um inteiro',
    },
    date: {
      min: '${path} deve ser posterior a ${min}',
      max: '${path} deve ser mais cedo do que ${max}',
    },
    boolean: {},
    object: {
      noUnknown:
        '${path} não pode ter atributos não especificados no formato do objeto',
    },
    array: {
      min: '${path} deve possuir ao menos ${min} itens',
      max: '${path} deve possuir no máximo ${max} itens',
    },
  },
  /* eslint-disable */
  fileUploader: {
    upload: 'Upload',
    image: 'Você deve fazer upload de uma imagem',
    size:
      'O arquivo é muito grande. O tamanho máximo permitido é {0}',
    formats: `Formato inválido. Deve ser: '{0}'.`,
  },
  importer: {
    line: 'Linha',
    status: 'Estado',
    pending: 'Pendente',
    imported: 'Importado',
    error: 'Erro',
    total: `{0} importado, {1} pendente e {2} com erro`,
    importedMessage: `Processados {0} de {1}.`,
    noNavigateAwayMessage:
      'Não saia desta página ou a importação será interrompida.',
    completed: {
      success:
        'Importação concluída. Todas as linhas foram importadas com sucesso.',
      someErrors:
        'O processamento foi concluído, mas algumas linhas não puderam ser importadas.',
      allErrors:
        'Importação falhou. Não há linhas válidas.',
    },
    form: {
      downloadTemplate: 'Baixe o modelo',
      hint:
        'Clique ou arraste o arquivo para esta área para continuar.',
    },
    list: {
      discardConfirm:
        'Você tem certeza? Dados não importados serão perdidos.',
    },
    errors: {
      invalidFileEmpty: 'O arquivo está vazio',
      invalidFileExcel:
        'Apenas arquivos Excel (.xlsx) são permitidos',
      invalidFileUpload:
        'Arquivo inválido. Verifique se você está usando a última versão do modelo.',
      importHashRequired: 'Hash de importação é necessário',
      importHashExistent: 'Dados já foram importados',
    },
  },

  autocomplete: {
    loading: 'Carregando...',
    noOptions: 'Não foram encontrados resultados',
  },

  imagesViewer: {
    noImage: 'Sem imagem',
  },

  table: {
    noData: 'Nenhum Registro Encontrado',
    loading: 'Carregando...',
  },

  pagination: {
    labelDisplayedRows: '{0}-{1} de {2}',
    labelRowsPerPage: 'Por página:',
  },

  firebaseErrors: {
    'auth/user-disabled': 'Sua conta está desativada',
    'auth/user-not-found': `Desculpe, não reconhecemos suas credenciais`,
    'auth/wrong-password': `Desculpe, não reconhecemos suas credenciais`,
    'auth/weak-password': 'Esta senha é muito fraca',
    'auth/email-already-in-use':
      'O email já está sendo usado',
    'auth/invalid-email':
      'Por favor forneça um email válido',
    'auth/account-exists-with-different-credential':
      'O email já está em uso para um método de autenticação diferente.',
    'auth/credential-already-in-use':
      'Credenciais já estão em uso',
  },
};

export default ptBR;
