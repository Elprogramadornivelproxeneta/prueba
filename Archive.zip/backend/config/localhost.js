module.exports = {
  env: 'localhost',

  /**
   * Configuration to allow email sending used on:
   * backend/src/services/shared/email/emailSender.js
   *
   * More info: https://nodemailer.com
   */
  email: {
    from: 'einar.guerrero@me.com',
    host: 'smtp.mail.me.com',
    auth: {
      user: 'einar.guerrero@me.com',
      pass: 'jpbn-qxwq-cnsw-rynf',
    },
  },

  /**
   * Client URL used when sending emails.
   */
  clientUrl: 'https://gasmate-f6761.firebaseapp.com',

  /**
   * When this email is set, all requests will automatically authenticate using this email.
   * Useful for testing purposes.
   */
  userAutoAuthenticatedEmailForTests:
    null,


};
