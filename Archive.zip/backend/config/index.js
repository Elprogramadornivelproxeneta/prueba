/**
 * This method is responsible for checking the current environment and
 * returning the correct config.
 */
module.exports = function get() {
  const isMigration = !!process.env.MIGRATION_ENV;

  if (isMigration) {
    const config = require(`./${
      process.env.MIGRATION_ENV
    }`);

    return config;
  }

  const isAppEngineEnv = !!process.env.APP_ENGINE_ENV;

  if (isAppEngineEnv) {
    const config = require(`./${
      process.env.APP_ENGINE_ENV
    }`);

    return config;
  }

  const isTest = process.env.NODE_ENV === 'test';

  if (isTest) {
    return require('./test');
  }

  const functions = require('firebase-functions');

  const isLocalhost =
    !functions.config() ||
    !functions.config().env ||
    !functions.config().env.value ||
    functions.config().env.value === 'localhost';

  if (isLocalhost) {
    return require('./localhost');
  }

  return require(`./${functions.config().env.value}`);
};
