module.exports = (app) => {
  app.post(`/tanks`, require('./tanksCreate'));
  app.put(`/tanks/:id`, require('./tanksUpdate'));
  app.post(`/tanks/import`, require('./tanksImport'));
  app.delete(`/tanks`, require('./tanksDestroy'));
  app.get(
    `/tanks/autocomplete`,
    require('./tanksAutocomplete'),
  );
  app.get(`/tanks`, require('./tanksList'));
  app.get(`/tanks/:id`, require('./tanksFind'));
};
