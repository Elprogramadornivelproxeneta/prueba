module.exports = (app) => {
  app.post(`/maintenance-templates`, require('./maintenanceTemplatesCreate'));
  app.put(`/maintenance-templates/:id`, require('./maintenanceTemplatesUpdate'));
  app.post(`/maintenance-templates/import`, require('./maintenanceTemplatesImport'));
  app.delete(`/maintenance-templates`, require('./maintenanceTemplatesDestroy'));
  app.get(
    `/maintenance-templates/autocomplete`,
    require('./maintenanceTemplatesAutocomplete'),
  );
  app.get(`/maintenance-templates`, require('./maintenanceTemplatesList'));
  app.get(`/maintenance-templates/:id`, require('./maintenanceTemplatesFind'));
};
