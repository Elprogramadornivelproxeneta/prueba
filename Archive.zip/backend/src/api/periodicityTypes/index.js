module.exports = (app) => {
  app.post(`/periodicity-types`, require('./periodicityTypesCreate'));
  app.put(`/periodicity-types/:id`, require('./periodicityTypesUpdate'));
  app.post(`/periodicity-types/import`, require('./periodicityTypesImport'));
  app.delete(`/periodicity-types`, require('./periodicityTypesDestroy'));
  app.get(
    `/periodicity-types/autocomplete`,
    require('./periodicityTypesAutocomplete'),
  );
  app.get(`/periodicity-types`, require('./periodicityTypesList'));
  app.get(`/periodicity-types/:id`, require('./periodicityTypesFind'));
};
