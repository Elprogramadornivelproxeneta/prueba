module.exports = (app) => {
  app.post(`/stations`, require('./stationsCreate'));
  app.put(`/stations/:id`, require('./stationsUpdate'));
  app.post(`/stations/import`, require('./stationsImport'));
  app.delete(`/stations`, require('./stationsDestroy'));
  app.get(
    `/stations/autocomplete`,
    require('./stationsAutocomplete'),
  );
  app.get(`/stations`, require('./stationsList'));
  app.get(`/stations/:id`, require('./stationsFind'));
};
