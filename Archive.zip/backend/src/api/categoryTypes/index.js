module.exports = (app) => {
  app.post(`/category-types`, require('./categoryTypesCreate'));
  app.put(`/category-types/:id`, require('./categoryTypesUpdate'));
  app.post(`/category-types/import`, require('./categoryTypesImport'));
  app.delete(`/category-types`, require('./categoryTypesDestroy'));
  app.get(
    `/category-types/autocomplete`,
    require('./categoryTypesAutocomplete'),
  );
  app.get(`/category-types`, require('./categoryTypesList'));
  app.get(`/category-types/:id`, require('./categoryTypesFind'));
};
