module.exports = (app) => {
  app.post(`/persons`, require('./personsCreate'));
  app.put(`/persons/:id`, require('./personsUpdate'));
  app.post(`/persons/import`, require('./personsImport'));
  app.delete(`/persons`, require('./personsDestroy'));
  app.get(
    `/persons/autocomplete`,
    require('./personsAutocomplete'),
  );
  app.get(`/persons`, require('./personsList'));
  app.get(`/persons/:id`, require('./personsFind'));
};
