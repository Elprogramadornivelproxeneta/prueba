module.exports = (app) => {
  app.post(`/task-templates`, require('./taskTemplatesCreate'));
  app.put(`/task-templates/:id`, require('./taskTemplatesUpdate'));
  app.post(`/task-templates/import`, require('./taskTemplatesImport'));
  app.delete(`/task-templates`, require('./taskTemplatesDestroy'));
  app.get(
    `/task-templates/autocomplete`,
    require('./taskTemplatesAutocomplete'),
  );
  app.get(`/task-templates`, require('./taskTemplatesList'));
  app.get(`/task-templates/:id`, require('./taskTemplatesFind'));
};
