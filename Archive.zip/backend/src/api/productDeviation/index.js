module.exports = (app) => {
  app.post(`/product-deviation`, require('./productDeviationCreate'));
  app.put(`/product-deviation/:id`, require('./productDeviationUpdate'));
  app.post(`/product-deviation/import`, require('./productDeviationImport'));
  app.delete(`/product-deviation`, require('./productDeviationDestroy'));
  app.get(
    `/product-deviation/autocomplete`,
    require('./productDeviationAutocomplete'),
  );
  app.get(`/product-deviation`, require('./productDeviationList'));
  app.get(`/product-deviation/:id`, require('./productDeviationFind'));
};
