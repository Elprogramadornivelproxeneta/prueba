module.exports = (app) => {
  app.post(`/product-reception`, require('./productReceptionCreate'));
  app.put(`/product-reception/:id`, require('./productReceptionUpdate'));
  app.post(`/product-reception/import`, require('./productReceptionImport'));
  app.delete(`/product-reception`, require('./productReceptionDestroy'));
  app.get(
    `/product-reception/autocomplete`,
    require('./productReceptionAutocomplete'),
  );
  app.get(`/product-reception`, require('./productReceptionList'));
  app.get(`/product-reception/:id`, require('./productReceptionFind'));
};
