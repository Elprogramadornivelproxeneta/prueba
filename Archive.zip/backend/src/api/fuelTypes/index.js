module.exports = (app) => {
  app.post(`/fuel-types`, require('./fuelTypesCreate'));
  app.put(`/fuel-types/:id`, require('./fuelTypesUpdate'));
  app.post(`/fuel-types/import`, require('./fuelTypesImport'));
  app.delete(`/fuel-types`, require('./fuelTypesDestroy'));
  app.get(
    `/fuel-types/autocomplete`,
    require('./fuelTypesAutocomplete'),
  );
  app.get(`/fuel-types`, require('./fuelTypesList'));
  app.get(`/fuel-types/:id`, require('./fuelTypesFind'));
};
