module.exports = (app) => {
  app.post(`/maintenance-types`, require('./maintenanceTypesCreate'));
  app.put(`/maintenance-types/:id`, require('./maintenanceTypesUpdate'));
  app.post(`/maintenance-types/import`, require('./maintenanceTypesImport'));
  app.delete(`/maintenance-types`, require('./maintenanceTypesDestroy'));
  app.get(
    `/maintenance-types/autocomplete`,
    require('./maintenanceTypesAutocomplete'),
  );
  app.get(`/maintenance-types`, require('./maintenanceTypesList'));
  app.get(`/maintenance-types/:id`, require('./maintenanceTypesFind'));
};
