module.exports = (app) => {
  app.post(`/work-orders`, require('./workOrdersCreate'));
  app.put(`/work-orders/:id`, require('./workOrdersUpdate'));
  app.post(`/work-orders/import`, require('./workOrdersImport'));
  app.delete(`/work-orders`, require('./workOrdersDestroy'));
  app.get(
    `/work-orders/autocomplete`,
    require('./workOrdersAutocomplete'),
  );
  app.get(`/work-orders`, require('./workOrdersList'));
  app.get(`/work-orders/:id`, require('./workOrdersFind'));
};
