module.exports = (app) => {
  app.post(`/addresses`, require('./addressesCreate'));
  app.put(`/addresses/:id`, require('./addressesUpdate'));
  app.post(`/addresses/import`, require('./addressesImport'));
  app.delete(`/addresses`, require('./addressesDestroy'));
  app.get(
    `/addresses/autocomplete`,
    require('./addressesAutocomplete'),
  );
  app.get(`/addresses`, require('./addressesList'));
  app.get(`/addresses/:id`, require('./addressesFind'));
};
