module.exports = (app) => {
  app.post(`/tasks`, require('./tasksCreate'));
  app.put(`/tasks/:id`, require('./tasksUpdate'));
  app.post(`/tasks/import`, require('./tasksImport'));
  app.delete(`/tasks`, require('./tasksDestroy'));
  app.get(
    `/tasks/autocomplete`,
    require('./tasksAutocomplete'),
  );
  app.get(`/tasks`, require('./tasksList'));
  app.get(`/tasks/:id`, require('./tasksFind'));
};
