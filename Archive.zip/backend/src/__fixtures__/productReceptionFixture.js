const genericFixture = require('./genericFixture');
const ProductReceptionRepository = require('../database/repositories/productReceptionRepository');

const productReceptionFixture = genericFixture({
  idField: 'id',
  createFn: (data) => new ProductReceptionRepository().create(data),
  data: [
    {
      id: '1',
      // Add attributes here
    },
  ],
});

module.exports = productReceptionFixture;
