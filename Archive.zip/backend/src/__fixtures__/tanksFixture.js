const genericFixture = require('./genericFixture');
const TanksRepository = require('../database/repositories/tanksRepository');

const tanksFixture = genericFixture({
  idField: 'id',
  createFn: (data) => new TanksRepository().create(data),
  data: [
    {
      id: '1',
      // Add attributes here
    },
  ],
});

module.exports = tanksFixture;
