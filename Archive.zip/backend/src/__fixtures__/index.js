const userFixture = require('./userFixture');
const personsFixture = require('./personsFixture');
const stationsFixture = require('./stationsFixture');
const addressesFixture = require('./addressesFixture');
const maintenanceTemplatesFixture = require('./maintenanceTemplatesFixture');
const categoryTypesFixture = require('./categoryTypesFixture');
const taskTemplatesFixture = require('./taskTemplatesFixture');
const workOrdersFixture = require('./workOrdersFixture');
const tasksFixture = require('./tasksFixture');
const maintenanceTypesFixture = require('./maintenanceTypesFixture');
const periodicityTypesFixture = require('./periodicityTypesFixture');
const fuelTypesFixture = require('./fuelTypesFixture');
const tanksFixture = require('./tanksFixture');
const productReceptionFixture = require('./productReceptionFixture');
const productDeviationFixture = require('./productDeviationFixture');
const AbstractRepository = require('../database/repositories/abstractRepository');

module.exports = {
  user: userFixture,
  persons: personsFixture,
  stations: stationsFixture,
  addresses: addressesFixture,
  maintenanceTemplates: maintenanceTemplatesFixture,
  categoryTypes: categoryTypesFixture,
  taskTemplates: taskTemplatesFixture,
  workOrders: workOrdersFixture,
  tasks: tasksFixture,
  maintenanceTypes: maintenanceTypesFixture,
  periodicityTypes: periodicityTypesFixture,
  fuelTypes: fuelTypesFixture,
  tanks: tanksFixture,
  productReception: productReceptionFixture,
  productDeviation: productDeviationFixture,

  async cleanDatabase() {
    await AbstractRepository.cleanDatabase();
  },
};
