const genericFixture = require('./genericFixture');
const StationsRepository = require('../database/repositories/stationsRepository');

const stationsFixture = genericFixture({
  idField: 'id',
  createFn: (data) => new StationsRepository().create(data),
  data: [
    {
      id: '1',
      // Add attributes here
    },
  ],
});

module.exports = stationsFixture;
