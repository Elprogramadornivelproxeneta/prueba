const genericFixture = require('./genericFixture');
const FuelTypesRepository = require('../database/repositories/fuelTypesRepository');

const fuelTypesFixture = genericFixture({
  idField: 'id',
  createFn: (data) => new FuelTypesRepository().create(data),
  data: [
    {
      id: '1',
      // Add attributes here
    },
  ],
});

module.exports = fuelTypesFixture;
