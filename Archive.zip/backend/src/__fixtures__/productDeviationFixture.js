const genericFixture = require('./genericFixture');
const ProductDeviationRepository = require('../database/repositories/productDeviationRepository');

const productDeviationFixture = genericFixture({
  idField: 'id',
  createFn: (data) => new ProductDeviationRepository().create(data),
  data: [
    {
      id: '1',
      // Add attributes here
    },
  ],
});

module.exports = productDeviationFixture;
