const genericFixture = require('./genericFixture');
const TaskTemplatesRepository = require('../database/repositories/taskTemplatesRepository');

const taskTemplatesFixture = genericFixture({
  idField: 'id',
  createFn: (data) => new TaskTemplatesRepository().create(data),
  data: [
    {
      id: '1',
      // Add attributes here
    },
  ],
});

module.exports = taskTemplatesFixture;
