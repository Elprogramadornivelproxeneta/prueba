const genericFixture = require('./genericFixture');
const PersonsRepository = require('../database/repositories/personsRepository');

const personsFixture = genericFixture({
  idField: 'id',
  createFn: (data) => new PersonsRepository().create(data),
  data: [
    {
      id: '1',
      // Add attributes here
    },
  ],
});

module.exports = personsFixture;
