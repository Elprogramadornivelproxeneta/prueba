const genericFixture = require('./genericFixture');
const MaintenanceTypesRepository = require('../database/repositories/maintenanceTypesRepository');

const maintenanceTypesFixture = genericFixture({
  idField: 'id',
  createFn: (data) => new MaintenanceTypesRepository().create(data),
  data: [
    {
      id: '1',
      // Add attributes here
    },
  ],
});

module.exports = maintenanceTypesFixture;
