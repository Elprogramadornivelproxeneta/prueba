const genericFixture = require('./genericFixture');
const MaintenanceTemplatesRepository = require('../database/repositories/maintenanceTemplatesRepository');

const maintenanceTemplatesFixture = genericFixture({
  idField: 'id',
  createFn: (data) => new MaintenanceTemplatesRepository().create(data),
  data: [
    {
      id: '1',
      // Add attributes here
    },
  ],
});

module.exports = maintenanceTemplatesFixture;
