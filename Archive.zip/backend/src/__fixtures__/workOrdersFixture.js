const genericFixture = require('./genericFixture');
const WorkOrdersRepository = require('../database/repositories/workOrdersRepository');

const workOrdersFixture = genericFixture({
  idField: 'id',
  createFn: (data) => new WorkOrdersRepository().create(data),
  data: [
    {
      id: '1',
      // Add attributes here
    },
  ],
});

module.exports = workOrdersFixture;
