const genericFixture = require('./genericFixture');
const AddressesRepository = require('../database/repositories/addressesRepository');

const addressesFixture = genericFixture({
  idField: 'id',
  createFn: (data) => new AddressesRepository().create(data),
  data: [
    {
      id: '1',
      // Add attributes here
    },
  ],
});

module.exports = addressesFixture;
