const genericFixture = require('./genericFixture');
const PeriodicityTypesRepository = require('../database/repositories/periodicityTypesRepository');

const periodicityTypesFixture = genericFixture({
  idField: 'id',
  createFn: (data) => new PeriodicityTypesRepository().create(data),
  data: [
    {
      id: '1',
      // Add attributes here
    },
  ],
});

module.exports = periodicityTypesFixture;
