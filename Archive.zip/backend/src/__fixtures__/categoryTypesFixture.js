const genericFixture = require('./genericFixture');
const CategoryTypesRepository = require('../database/repositories/categoryTypesRepository');

const categoryTypesFixture = genericFixture({
  idField: 'id',
  createFn: (data) => new CategoryTypesRepository().create(data),
  data: [
    {
      id: '1',
      // Add attributes here
    },
  ],
});

module.exports = categoryTypesFixture;
