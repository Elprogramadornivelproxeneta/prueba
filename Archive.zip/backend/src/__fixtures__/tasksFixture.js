const genericFixture = require('./genericFixture');
const TasksRepository = require('../database/repositories/tasksRepository');

const tasksFixture = genericFixture({
  idField: 'id',
  createFn: (data) => new TasksRepository().create(data),
  data: [
    {
      id: '1',
      // Add attributes here
    },
  ],
});

module.exports = tasksFixture;
