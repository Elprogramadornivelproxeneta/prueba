const types = require('./types');
const AbstractEntityModel = require('./abstractEntityModel');

module.exports = class MaintenanceTypes extends AbstractEntityModel {
  constructor() {
    super('maintenanceTypes', 'maintenanceTypes', {
      order: new types.Number(1, 100),
      name: new types.String(2, 255),
      description: new types.String(null, null),
      importHash: new types.String(null, 255),
    });
  }
};
