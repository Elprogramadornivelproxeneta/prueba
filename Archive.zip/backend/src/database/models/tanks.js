const types = require('./types');
const AbstractEntityModel = require('./abstractEntityModel');

module.exports = class Tanks extends AbstractEntityModel {
  constructor() {
    super('tanks', 'tanks', {
      tankNumber: new types.Number(1, 100),
      fuelType: new types.RelationToOne(),
      volume: new types.Number(null, null),
      station: new types.RelationToOne(),
      importHash: new types.String(null, 255),
    });
  }
};
