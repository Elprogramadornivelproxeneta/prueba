const types = require('./types');
const AbstractEntityModel = require('./abstractEntityModel');

module.exports = class WorkOrders extends AbstractEntityModel {
  constructor() {
    super('workOrders', 'workOrders', {
      station: new types.RelationToOne(),
      maintenanceTemplate: new types.RelationToOne(),
      title: new types.String(null, null),
      status: new types.Enumerator([
        "PENDING",
        "ASSIGNED",
        "IN_PROGRESS",
        "DONE"
      ]),
      plannedStartOn: new types.Date(),
      actualStartOn: new types.DateTime(),
      finishedOn: new types.DateTime(),
      duration: new types.Number(null, null),
      operator: new types.RelationToOne(),
      tasks: new types.RelationToMany(),
      files: new types.Files(),
      signature: new types.Files(),
      evidences: new types.Files(),
      importHash: new types.String(null, 255),
    });
  }
};
