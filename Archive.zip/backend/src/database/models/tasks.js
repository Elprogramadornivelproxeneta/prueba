const types = require('./types');
const AbstractEntityModel = require('./abstractEntityModel');

module.exports = class Tasks extends AbstractEntityModel {
  constructor() {
    super('tasks', 'tasks', {
      result: new types.Enumerator([
        "VALID",
        "INVALID"
      ]),
      evidences: new types.Files(),
      workOrderId: new types.RelationToOne(),
      taskTemplateId: new types.RelationToOne(),
      name: new types.String(null, null),
      importHash: new types.String(null, 255),
    });
  }
};
