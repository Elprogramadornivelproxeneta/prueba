const types = require('./types');
const AbstractEntityModel = require('./abstractEntityModel');

module.exports = class TaskTemplates extends AbstractEntityModel {
  constructor() {
    super('taskTemplates', 'taskTemplates', {
      order: new types.Number(1, 100),
      name: new types.String(5, 255),
      description: new types.String(null, 1000),
      isEvidenceRequired: new types.Boolean(),
      maintenanceTemplateId: new types.RelationToOne(),
      importHash: new types.String(null, 255),
    });
  }
};
