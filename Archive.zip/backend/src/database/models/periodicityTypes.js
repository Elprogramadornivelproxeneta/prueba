const types = require('./types');
const AbstractEntityModel = require('./abstractEntityModel');

module.exports = class PeriodicityTypes extends AbstractEntityModel {
  constructor() {
    super('periodicityTypes', 'periodicityTypes', {
      order: new types.Number(1, 100),
      name: new types.String(null, null),
      increment: new types.Number(1, null),
      unit: new types.String(null, null),
      importHash: new types.String(null, 255),
    });
  }
};
