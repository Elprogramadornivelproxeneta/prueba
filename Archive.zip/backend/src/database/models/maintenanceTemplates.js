const types = require('./types');
const AbstractEntityModel = require('./abstractEntityModel');

module.exports = class MaintenanceTemplates extends AbstractEntityModel {
  constructor() {
    super('maintenanceTemplates', 'maintenanceTemplates', {
      identifier: new types.String(3, 20),
      name: new types.String(2, 255),
      description: new types.String(null, 1024),
      maintenanceType: new types.RelationToOne(),
      priority: new types.Enumerator([
        "Alta",
        "Media",
        "Baja"
      ]),
      version: new types.Number(null, null),
      category: new types.RelationToOne(),
      periodicity: new types.RelationToOne(),
      duration: new types.String(null, 5),
      isEvidenceRequired: new types.Boolean(),
      isSignatureRequired: new types.Boolean(),
      tasks: new types.RelationToMany(),
      relatedMaintenances: new types.RelationToMany(),
      importHash: new types.String(null, 255),
    });
  }
};
