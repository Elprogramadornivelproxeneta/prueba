const types = require('./types');
const AbstractEntityModel = require('./abstractEntityModel');

module.exports = class Persons extends AbstractEntityModel {
  constructor() {
    super('persons', 'persons', {
      userId: new types.RelationToOne(),
      name: new types.String(2, 255),
      paternalSurname: new types.String(2, 255),
      maternalSurname: new types.String(2, 255),
      gender: new types.Enumerator([
        "male",
        "female"
      ]),
      birthdate: new types.Date(),
      rfc: new types.String(10, 13),
      curp: new types.String(18, 18),
      identityDocument: new types.Files(),
      identityDocumentType: new types.Enumerator([
        "INE",
        "Pasaporte",
        "Licencia"
      ]),
      stations: new types.RelationToMany(),
      importHash: new types.String(null, 255),
    });
  }
};
