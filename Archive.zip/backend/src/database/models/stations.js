const types = require('./types');
const AbstractEntityModel = require('./abstractEntityModel');

module.exports = class Stations extends AbstractEntityModel {
  constructor() {
    super('stations', 'stations', {
      identifier: new types.String(null, 50),
      name: new types.String(null, null),
      address: new types.RelationToOne(),
      legalRepresentative: new types.RelationToOne(),
      users: new types.RelationToMany(),
      maintenanceTemplates: new types.RelationToMany(),
      tanks: new types.RelationToMany(),
      importHash: new types.String(null, 255),
    });
  }
};
