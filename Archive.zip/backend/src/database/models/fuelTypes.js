const types = require('./types');
const AbstractEntityModel = require('./abstractEntityModel');

module.exports = class FuelTypes extends AbstractEntityModel {
  constructor() {
    super('fuelTypes', 'fuelTypes', {
      name: new types.String(null, null),
      description: new types.String(null, null),
      importHash: new types.String(null, 255),
    });
  }
};
