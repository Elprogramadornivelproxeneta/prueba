const types = require('./types');
const AbstractEntityModel = require('./abstractEntityModel');

module.exports = class Addresses extends AbstractEntityModel {
  constructor() {
    super('addresses', 'addresses', {
      addressLine1: new types.String(null, null),
      addressLine2: new types.String(null, null),
      postalCode: new types.String(5, 5),
      colony: new types.String(null, null),
      municipality: new types.String(null, null),
      state: new types.Enumerator([
        "AGS",
        "CDMX"
      ]),
      importHash: new types.String(null, 255),
    });
  }
};
