const types = require('./types');
const AbstractEntityModel = require('./abstractEntityModel');

module.exports = class ProductDeviation extends AbstractEntityModel {
  constructor() {
    super('productDeviation', 'productDeviation', {
      tank: new types.RelationToOne(),
      initialInventoryVedeer: new types.Number(null, null),
      finalInventoryVedeer: new types.Number(null, null),
      volumePurchased: new types.Number(null, null),
      volumeSold: new types.Number(null, null),
      finalPhysicalInventory: new types.Number(null, null),
      difference: new types.Number(null, null),
      importHash: new types.String(null, 255),
    });
  }
};
