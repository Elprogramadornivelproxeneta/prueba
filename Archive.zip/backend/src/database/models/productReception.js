const types = require('./types');
const AbstractEntityModel = require('./abstractEntityModel');

module.exports = class ProductReception extends AbstractEntityModel {
  constructor() {
    super('productReception', 'productReception', {
      referral: new types.String(null, null),
      tank: new types.RelationToOne(),
      quantity: new types.Number(null, null),
      startTime: new types.DateTime(),
      endTime: new types.DateTime(),
      importHash: new types.String(null, 255),
    });
  }
};
