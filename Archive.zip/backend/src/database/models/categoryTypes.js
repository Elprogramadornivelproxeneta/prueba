const types = require('./types');
const AbstractEntityModel = require('./abstractEntityModel');

module.exports = class CategoryTypes extends AbstractEntityModel {
  constructor() {
    super('categoryTypes', 'categoryTypes', {
      name: new types.String(null, 255),
      description: new types.String(null, 1024),
      order: new types.Number(null, 100),
      importHash: new types.String(null, 255),
    });
  }
};
